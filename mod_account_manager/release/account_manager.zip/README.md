### account_manager v1.05 ###
by S0me0ne, 
reworked by spoter and ShadowHunterRUS


### Usage: ###
Start:
press AccountManager icon on login page
