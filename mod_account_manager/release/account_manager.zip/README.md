### account_manager_extended v1.06 ###
by S0me0ne, 
reworked by spoter and ShadowHunterRUS


### Usage: ###
Start:
Click the Account Manager icon on login page
