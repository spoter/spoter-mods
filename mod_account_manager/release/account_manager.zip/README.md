### account_manager_extended v1.02 ###
by S0me0ne, 
reworked by spoter and ShadowHunterRUS


### Usage: ###
Start:
press AccountManager icon on login page
