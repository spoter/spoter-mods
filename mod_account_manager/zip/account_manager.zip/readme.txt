account_manager_extended v1.01, 
by S0me0ne, 
reworked by spoter


Usage:
Start:
CTRL+B: open mod window

Edit:
mouse click: login in game
CTRL+mouse click: edit data
ALT+mouse click: delete data