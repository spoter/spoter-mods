﻿# -*- coding: utf-8-sig -*-
import BigWorld, os, re, json, codecs, datetime, threading, urllib, urllib2, math
from gui.Scaleform.daapi.view.meta.CrewMeta import CrewMeta
from gui.shared.gui_items.dossier import TankmanDossier
from constants import AUTH_REALM
from gui.Scaleform.daapi.view.lobby.hangar import Hangar
from CurrentVehicle import g_currentVehicle
from items.tankmen import MAX_SKILL_LEVEL
from gui.Scaleform.daapi.view.meta.CrewMeta import CrewMeta
from gui.Scaleform.daapi.view.meta.BarracksMeta import BarracksMeta
from gui.Scaleform.locale.MENU import MENU
from helpers import i18n
from gui.shared import g_itemsCache

class Config(object):
    def __init__(self):
        self.default_config()
        self.sys_mess()
        new_config = self.load_json('crew_extended',self.data)
        self.data = new_config
        self.analitycs_init()

    def default_config(self):
        try:
            import xvm_main
            self.XVMInstalled = True
        except:
            self.XVMInstalled = False
        self.ru = True if AUTH_REALM == 'RU' else False
        self.tid = 'UA-57975916-10'
        self.name = 'crew_extended'
        self.description = 'crew_extended'
        self.author = 'by spoter'
        self.version = 'v4.00(06.07.2015)'
        self.description_analitycs = 'Мод: "Экипаж"'
        self._enable = True
        self._debug = False
        self.data = {}
        self.data['config'] = {}
        self.data['config']['enable'] = True
        self.data['config']['debug'] = False
        self.data['config']['hangar_crew'] = True
        self.data['config']['barracks_crew'] = True
        self.data['config']['language'] = 'English'
        self.data['language'] = {}
        self.data['language']['Русский'] = {}
        self.data['language']['English'] = {}
        self.data['language']['Deutsch'] = {}
        self.data['language']['Русский']['personal_file'] = {}
        self.data['language']['Русский']['personal_file']['premium_bonus_on'] = 'Премиум бонус на опыт: Активирован'
        self.data['language']['Русский']['personal_file']['premium_bonus_off'] = 'Премиум бонус на опыт: Неактивен'
        self.data['language']['Русский']['personal_file']['value_to'] = 'Опыта до'
        self.data['language']['Русский']['personal_file']['skill_number'] = 'Навык'
        self.data['language']['Русский']['personal_file']['basic_skill'] = 'Базовый навык'
        self.data['language']['Русский']['personal_file']['relearn'] = 'Переобучение'
        self.data['language']['Русский']['personal_file']['relearn_need'] = 'за кредиты надо'
        self.data['language']['Русский']['personal_file']['relearn_ready'] = 'за кредиты Готово!'
        self.data['language']['Русский']['personal_file']['relearn_notready'] = 'за кредиты не доступно'
        self.data['language']['Русский']['personal_file']['skilldrop'] = 'Уровень умения, после сброса за кредиты'
        self.data['language']['Русский']['personal_file']['skilldrop_ready'] = 'Возможен сброс умений за кредиты'
        self.data['language']['Русский']['hangar_crew'] = {}
        self.data['language']['Русский']['hangar_crew']['rank_string'] = u'[{exp-step-battles}|{exp-step}] {rank}'
        self.data['language']['Русский']['hangar_crew']['lastname_string'] = u'{lastname}'
        self.data['language']['Русский']['hangar_crew']['firstname_string'] = u'{firstname}'
        self.data['language']['Русский']['hangar_crew']['role_string'] = u'[<font color="#00FF00">{training-battles}</font><img align="top" src="img://gui/maps//icons/library/BattleResultIcon-1.png" height="14" width="14" vspace="-3"/><font color="#FFFF00">{exp-total}</font><img align="top" src="img://gui/maps//icons/library/XpIcon-1.png" height="16" width="16" vspace="-3"/>]{role}'
        self.data['language']['Русский']['hangar_crew']['vehicletype_string'] = u'{vehicleType}'
        self.data['language']['Русский']['barracks_crew'] = {}
        self.data['language']['Русский']['barracks_crew']['rank_string'] = u'{role}'
        self.data['language']['Русский']['barracks_crew']['lastname_string'] = u'{lastname}'
        self.data['language']['Русский']['barracks_crew']['firstname_string'] = u'[{training-battles}|{exp-total}] {firstname}'
        self.data['language']['Русский']['barracks_crew']['role_string'] = u'{skillicons}{training-progress}%'
        self.data['language']['Русский']['barracks_crew']['vehicletype_string'] = u'{vehicleType}'
        self.data['language']['Русский']['ordinator'] = {}
        self.data['language']['Русский']['ordinator']['none'] = '-й'

        self.data['language']['Deutsch']['personal_file'] = {}
        self.data['language']['Deutsch']['personal_file']['premium_bonus_on'] = u'Erfahrungsbonus'
        self.data['language']['Deutsch']['personal_file']['premium_bonus_off'] = u'Kein Erfahrungsbonus'
        self.data['language']['Deutsch']['personal_file']['value_to'] = u'f%sr' %(unichr(252))
        self.data['language']['Deutsch']['personal_file']['skill_number'] = u'Fertigkeit'
        self.data['language']['Deutsch']['personal_file']['basic_skill'] = u'Grundfertigkeit'
        self.data['language']['Deutsch']['personal_file']['relearn'] = u'Umschulung f%sr Kreditpunkte' %(unichr(252))
        self.data['language']['Deutsch']['personal_file']['relearn_need'] = u'ben%stigt weitere' %(unichr(246))
        self.data['language']['Deutsch']['personal_file']['relearn_ready'] = u'verf%sgbar!' %(unichr(252))
        self.data['language']['Deutsch']['personal_file']['relearn_notready'] = u'nicht verf%sgbar!' %(unichr(252))
        self.data['language']['Deutsch']['personal_file']['skilldrop'] = u'Neue Ausbildungsstufe nach verlernen'
        self.data['language']['Deutsch']['personal_file']['skilldrop_ready'] = u'Verlernen f%sr Kreditpunkte verf%sgbar!' %(unichr(252),unichr(252))
        self.data['language']['Deutsch']['hangar_crew'] = {}
        self.data['language']['Deutsch']['hangar_crew']['rank_string'] = u'[{exp-step-battles}|{exp-step}] {rank}'        
        self.data['language']['Deutsch']['hangar_crew']['lastname_string'] = u'{lastname}'
        self.data['language']['Deutsch']['hangar_crew']['firstname_string'] = u'{firstname}'
        self.data['language']['Deutsch']['hangar_crew']['role_string'] = u'[<font color="#00FF00">{training-battles}</font><img align="top" src="img://gui/maps//icons/library/BattleResultIcon-1.png" height="14" width="14" vspace="-3"/><font color="#FFFF00">{exp-total}</font><img align="top" src="img://gui/maps//icons/library/XpIcon-1.png" height="16" width="16" vspace="-3"/>]{role}'
        self.data['language']['Deutsch']['hangar_crew']['vehicletype_string'] = u'{vehicleType}'
        self.data['language']['Deutsch']['barracks_crew'] = {}
        self.data['language']['Deutsch']['barracks_crew']['rank_string'] = u'{role}'
        self.data['language']['Deutsch']['barracks_crew']['lastname_string'] = u'{lastname}'
        self.data['language']['Deutsch']['barracks_crew']['firstname_string'] = u'[{training-battles}|{exp-total}] {firstname}'
        self.data['language']['Deutsch']['barracks_crew']['role_string'] = u'{skillicons}{training-progress}%'
        self.data['language']['Deutsch']['barracks_crew']['vehicletype_string'] = u'{vehicleType}'
        self.data['language']['Deutsch']['ordinator'] = {}
        self.data['language']['Deutsch']['ordinator']['none'] = '.'

        self.data['language']['English']['personal_file'] = {}
        self.data['language']['English']['personal_file']['premium_bonus_on'] = 'Premium XP bonus'
        self.data['language']['English']['personal_file']['premium_bonus_off'] = 'No premium XP bonus'
        self.data['language']['English']['personal_file']['value_to'] = 'to'
        self.data['language']['English']['personal_file']['skill_number'] = 'Skill'
        self.data['language']['English']['personal_file']['basic_skill'] = 'Basic skill'
        self.data['language']['English']['personal_file']['relearn'] = 'Retraining for credits'
        self.data['language']['English']['personal_file']['relearn_need'] = 'needs further'
        self.data['language']['English']['personal_file']['relearn_ready'] = 'ready!'
        self.data['language']['English']['personal_file']['relearn_notready'] = 'not ready!'
        self.data['language']['English']['personal_file']['skilldrop'] = 'New skill level after dropping skills'
        self.data['language']['English']['personal_file']['skilldrop_ready'] = 'Dropping skills for credits ready!'
        self.data['language']['English']['hangar_crew'] = {}
        self.data['language']['English']['hangar_crew']['rank_string'] = u'[{exp-step-battles}|{exp-step}] {rank}'
        self.data['language']['English']['hangar_crew']['lastname_string'] = u'{lastname}'
        self.data['language']['English']['hangar_crew']['firstname_string'] = u'{firstname}'
        self.data['language']['English']['hangar_crew']['role_string'] = u'[<font color="#00FF00">{training-battles}</font><img align="top" src="img://gui/maps//icons/library/BattleResultIcon-1.png" height="14" width="14" vspace="-3"/><font color="#FFFF00">{exp-total}</font><img align="top" src="img://gui/maps//icons/library/XpIcon-1.png" height="16" width="16" vspace="-3"/>]{role}'
        self.data['language']['English']['hangar_crew']['vehicletype_string'] = u'{vehicleType}'
        self.data['language']['English']['barracks_crew'] = {}
        self.data['language']['English']['barracks_crew']['rank_string'] = u'{role}'
        self.data['language']['English']['barracks_crew']['lastname_string'] = u'{lastname}'
        self.data['language']['English']['barracks_crew']['firstname_string'] = u'[{training-battles}|{exp-total}] {firstname}'
        self.data['language']['English']['barracks_crew']['role_string'] = u'{skillicons}{training-progress}%'
        self.data['language']['English']['barracks_crew']['vehicletype_string'] = u'{vehicleType}'
        self.data['language']['English']['ordinator'] = {}
        self.data['language']['English']['ordinator']['none'] = 'th'
        self.data['language']['English']['ordinator'][1] = 'st'
        self.data['language']['English']['ordinator'][2] = 'nd'
        self.data['language']['English']['ordinator'][3] = 'rd'

    def do_config(self):
        self._enable = self.data['config']['enable']
        self._debug = self.data['config']['debug']
        if self.data['config']['language'] in self.data['language']: self._language = self.data['language'][self.data['config']['language']]
        else:
            self.data['config']['language'] = 'English'
            self._language = self.data['language']['English']
        self.ru = True if self.data['config']['language'] == 'Русский' else False

    def byteify(self,input):
        if input:
            if isinstance(input, dict):
                return {self.byteify(key):self.byteify(value) for key,value in input.iteritems()}
            elif isinstance(input, list):
                return [self.byteify(element) for element in input]
            elif isinstance(input, unicode):
                return input.encode('utf-8')
            else:
                return input
        return input
    
    def json_comments(self,text):
        regex = r'\s*(#|\/{2}).*$'
        regex_inline = r'(:?(?:\s)*([A-Za-z\d\.{}]*)|((?<=\").*\"),?)(?:\s)*(((#|(\/{2})).*)|)$'
        lines = text.split('\n')
        excluded = []
        for index, line in enumerate(lines):
            if re.search(regex, line):
                if re.search(r'^' + regex, line, re.IGNORECASE):
                    excluded.append(lines[index])
                elif re.search(regex_inline, line):
                    lines[index] = re.sub(regex_inline, r'\1', line)
        for line in excluded:
            lines.remove(line)
        return '\n'.join(lines)

    def load_json(self, name, config, save = False):
        config_new = config
        path = './res_mods/configs/spoter_mods/%s/' %self.name
        if not os.path.exists(path):
            os.makedirs(path)
        new_path = '%s%s.json' %(path,name)
        if save:
            with codecs.open(new_path, 'w',encoding='utf-8-sig') as json_file:
                data = json.dumps(config, sort_keys=True, indent=4,ensure_ascii=False,encoding='utf-8-sig',separators=(',', ': '))
                json_file.write('%s' %self.byteify(data))
                json_file.close()
                config_new = config
        else:
            if os.path.isfile(new_path):
                try:
                    with codecs.open(new_path, 'r',encoding='utf-8-sig') as json_file:
                        data = self.json_comments(json_file.read().decode('utf-8-sig'))
                        config_new = self.byteify(json.loads(data))
                        json_file.close()
                except Exception as e: print '%s%s' %(self.sys_mes['ERROR'],e)

            else:
                with codecs.open(new_path, 'w',encoding='utf-8-sig') as json_file:
                    data = json.dumps(config, sort_keys=True, indent=4,ensure_ascii=False,encoding='utf-8-sig',separators=(',', ': '))
                    json_file.write('%s' %self.byteify(data))
                    json_file.close()
                    config_new = config
        return config_new

    def codepa(self, text):
        try: return text.encode('windows-1251')
        except: return text

    def debugs(self, text):
        if self._debug:
            try: text = text.encode('windows-1251')
            except: pass
            print '%s%s [%s]: %s' %(datetime.datetime.now(),self.sys_mes['DEBUG'],self.codepa(self.description),text)

    def analitycs_init(self):
        try:
            if BigWorld._analitics_started:
                BigWorld._analitics_started[self.description_analitycs] = 0
        except:
            BigWorld._analitics_started = {}
            BigWorld._analitics_started[self.description_analitycs] = 0

    def analitycs_do(self):
        if BigWorld._analitics_started[self.description_analitycs] == 0:
            player = BigWorld.player()
            param = urllib.urlencode({
                            'v': 1,                                                     # Version.
                            'tid': '%s' %self.tid,                                      # Tracking ID / Property ID.
                            'cid': player.databaseID,                                   # Anonymous Client ID.
                            't': 'screenview',                                          # Screenview hit type.
                            'an': '%s' %self.description_analitycs,                     # App name.
                            'av': '%s %s' %(self.description_analitycs, self.version),  # App version.
                            'cd': 'start [%s]' %(AUTH_REALM)                            # Screen name / content description.
                         })
            self.debugs('http://www.google-analytics.com/collect?%s' %param )
            urllib2.urlopen(url='http://www.google-analytics.com/collect?',data=param).read()
            BigWorld._analitics_started[self.description_analitycs] = 1

    def analitycs(self):
        self._thread_analitycs = threading.Thread(target=self.analitycs_do, name='Thread')
        self._thread_analitycs.start()

    def sys_mess(self):
        self.sys_mes = {}
        self.sys_mes['DEBUG'] = '[DEBUG]'
        self.sys_mes['LOAD_MOD'] = self.codepa('[ЗАГРУЗКА]:  ') if self.ru else '[LOAD_MOD]:  '
        self.sys_mes['INFO'] = self.codepa('[ИНФО]:      ') if self.ru else '[INFO]:      '
        self.sys_mes['ERROR'] = self.codepa('[ОШИБКА]:    ') if self.ru else '[ERROR]:     '
        self.sys_mes['MSG_RECREATE_XML'] = self.codepa('XML конфиг не найден, создаем заново') if self.ru else 'XML not found, recreating'
        self.sys_mes['MSG_RECREATE_XML_DONE'] = self.codepa('XML конфиг создан УСПЕШНО') if self.ru else 'XML recreating DONE'
        self.sys_mes['MSG_INIT'] = self.codepa('применение настроек...') if self.ru else 'initialized ...'
        self.sys_mes['MSG_DISABLED'] = self.codepa('отключен ...') if self.ru else 'disabled ...'
        self.sys_mes['MSG_LANGUAGE_SET'] = self.codepa('Выбран язык:') if self.ru else 'Language set to:'
        if self.ru:
            self.description = 'Мод: "Экипаж"'
            self.author = 'автор: spoter'

    def load_mod(self):
        self.do_config()
        self.sys_mess()
        print ''
        print '%s[%s, %s]' %(self.sys_mes['LOAD_MOD'],self.codepa(self.description),self.codepa(self.author))
        if self._enable:
            self.debugs('Debug Activated ...')
            print '%s[%s %s %s...]' %(self.sys_mes['INFO'],self.codepa(self.description),self.sys_mes['MSG_LANGUAGE_SET'],self.codepa(self.data['config']['language']))
            print '%s[%s, %s %s]' %(self.sys_mes['INFO'],self.codepa(self.description),self.version,self.sys_mes['MSG_INIT'])
        else: print '%s[%s, %s %s]' %(self.sys_mes['INFO'],self.codepa(self.description),self.version,self.sys_mes['MSG_DISABLED'])
        print ''

class Personal_file(object):
    
    def __formatValueForUI(self, value):
        if value is None: return '%s' % i18n.makeString(MENU.PROFILE_STATS_ITEMS_EMPTY)
        else: return BigWorld.wg_getIntegralFormat(value)
    
    def __packStat(self, name = 'empty', value = None, premiumValue = None, imageType = None, image = None):
        if value and value < 1: value = 1
        if premiumValue and premiumValue < 1: value = 1
        value = self.__formatValueForUI(value)
        premiumValue = self.__formatValueForUI(premiumValue)
        return {'name': name, 'value': value, 'premiumValue': premiumValue, 'imageType': imageType, 'image': image}

    @staticmethod
    def secondLabel(vehicle, tankman):
        lastSkillNumber = tankman.descriptor.lastSkillNumber if not tankman.hasNewSkill else tankman.descriptor.lastSkillNumber + tankman.newSkillCount[0]
        ordinator = config._language['ordinator'][lastSkillNumber] if lastSkillNumber in config._language['ordinator'] else config._language['ordinator']['none']
        if vehicle.tmanDescr.roleLevel == MAX_SKILL_LEVEL:
            if vehicle._TankmanDossier__currentVehicleIsPremium: return '%s%s %s, x%s %s' %(lastSkillNumber, ordinator, config._language['personal_file']['skill_number'], vehicle._TankmanDossier__currentVehicleCrewXpFactor, config._language['personal_file']['premium_bonus_on'])
            else: return '%s%s %s, %s' %(lastSkillNumber, ordinator, config._language['personal_file']['skill_number'], config._language['personal_file']['premium_bonus_off'])
        else:
            if vehicle._TankmanDossier__currentVehicleIsPremium: return '%s, x%s %s' %(config._language['personal_file']['basic_skill'], vehicle._TankmanDossier__currentVehicleCrewXpFactor,config._language['personal_file']['premium_bonus_on'])
            else: return '%s, %s' %(config._language['personal_file']['basic_skill'], config._language['personal_file']['premium_bonus_off'])

    @staticmethod
    def nope():
        return {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None}

    @staticmethod    
    def title(tankman):
        NextSkillLevel = ((tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]) + 1
        return {'name': 'empty', 'value': '%s %s%%' %(config._language['personal_file']['value_to'], NextSkillLevel), 'premiumValue': '%s 100%%' %config._language['personal_file']['value_to'], 'imageType': None, 'image': None}
    
    @staticmethod
    def getNextSkillBattlesLeft(vehicle, tankman):
        if not vehicle.getBattlesCount() or not vehicle.extStats.getBattlesCount() or not vehicle.extStats.getXP(): result = None
        else:
            avgExp = vehicle.getAvgXP()
            newSkillReady = vehicle.tmanDescr.roleLevel == MAX_SKILL_LEVEL and (len(vehicle.tmanDescr.skills) == 0 or vehicle.tmanDescr.lastSkillLevel == MAX_SKILL_LEVEL)
            if avgExp and not newSkillReady: result = max(1, math.ceil(tankman.getNextSkillXpCost() / avgExp))
            else: result = 0
        return result
    
    def getStats(self, vehicle, tankman, data):
        data[0]['stats'] = (data[0]['stats'][0],data[0]['stats'][1],self.__packStat('xp', tankman.descriptor.totalXP()))
        data[1]['secondLabel'] = self.secondLabel(vehicle, tankman)
        data[1]['isPremium'] = True
        nextSkillXPLeft = self.__packStat('nextSkillXPLeft', tankman.getNextLevelXpCost(), tankman.getNextSkillXpCost(), imageType=data[1]['stats'][0]['imageType'], image=data[1]['stats'][0]['image'])
        if vehicle._TankmanDossier__currentVehicleIsPremium: nextSkillBattlesLeft = self.__packStat('nextSkillBattlesLeft', vehicle._TankmanDossier__getBattlesLeftOnPremiumVehicle(vehicle._TankmanDossier__getNextSkillBattlesLeft(tankman)), vehicle._TankmanDossier__getBattlesLeftOnPremiumVehicle(self.getNextSkillBattlesLeft(vehicle,tankman)))
        else: nextSkillBattlesLeft = self.__packStat('nextSkillBattlesLeft', vehicle._TankmanDossier__getNextSkillBattlesLeft(tankman), self.getNextSkillBattlesLeft(vehicle,tankman))
        data[1]['stats'] = (self.title(tankman), nextSkillXPLeft,nextSkillBattlesLeft)
        return data

class Hangar_crew(object):

    @staticmethod
    def fix_number(value):
        value = float(value)
        if value < 1000: return '%s' %int(value)
        elif value < 100000: return '{:0.1f}k'.format(value/1000.0)
        elif value < 1000000: return '{0:d}k'.format(int(math.ceil(value/1000.0)))
        else: return '{:0.1f}M'.format(value/1000000.0)
    
    @staticmethod
    def check_macros(macros):
        if macros in config._language['hangar_crew']['firstname_string']: return True
        if macros in config._language['hangar_crew']['lastname_string']: return True
        if macros in config._language['hangar_crew']['role_string']: return True
        if macros in config._language['hangar_crew']['vehicletype_string']: return True
        if macros in config._language['hangar_crew']['rank_string']: return True
        return False
    
    @staticmethod
    def isInTank_getNextSkillBattlesLeft(tankman):
        vehicle = g_itemsCache.items.getTankmanDossier(tankman.invID)
        currentVehicleItem = g_itemsCache.items.getVehicle(tankman.vehicleInvID)
        xpFactorToUse = 1.5
        currentVehicleType = currentVehicleItem.descriptor.type if currentVehicleItem else None
        isPremium = currentVehicleItem and currentVehicleItem.isPremium
        if not vehicle.getBattlesCount() or not vehicle.extStats.getBattlesCount() or not vehicle.extStats.getXP(): result = None
        else:
            avgExp = vehicle.getAvgXP()
            newSkillReady = vehicle.tmanDescr.roleLevel == MAX_SKILL_LEVEL and (len(vehicle.tmanDescr.skills) == 0 or vehicle.tmanDescr.lastSkillLevel == MAX_SKILL_LEVEL)
            if avgExp and not newSkillReady: result = max(1, math.ceil(tankman.getNextSkillXpCost() / avgExp))
            else: result = 0
        if isPremium: 
            xpFactorToUse = currentVehicleType.crewXpFactor if currentVehicleType else 1.0
            if result is not None:
                if result != 0:
                    return max(1, result / xpFactorToUse)
                return 0
        return result

    @staticmethod
    def isInTank_getNextLevelBattlesLeft(tankman):
        vehicle = g_itemsCache.items.getTankmanDossier(tankman.invID)
        currentVehicleItem = g_itemsCache.items.getVehicle(tankman.vehicleInvID)
        xpFactorToUse = 1.5
        currentVehicleType = currentVehicleItem.descriptor.type if currentVehicleItem else None
        isPremium = currentVehicleItem and currentVehicleItem.isPremium
        if not vehicle.getBattlesCount() or not vehicle.extStats.getBattlesCount() or not vehicle.extStats.getXP(): result = None
        else:
            avgExp = vehicle.getAvgXP()
            newSkillReady = vehicle.tmanDescr.roleLevel == MAX_SKILL_LEVEL and (len(vehicle.tmanDescr.skills) == 0 or vehicle.tmanDescr.lastSkillLevel == MAX_SKILL_LEVEL)
            if avgExp and not newSkillReady: result = max(1, math.ceil(tankman.getNextLevelXpCost() / avgExp))
            else: result = 0
        if isPremium:
            xpFactorToUse = currentVehicleType.crewXpFactor if currentVehicleType else 1.0
            if result is not None:
                if result != 0:
                    return max(1, result / xpFactorToUse)
                result = 0
        return result


    def training_battles(self, tankman):
        if tankman.isInTank: 
            result = self.isInTank_getNextSkillBattlesLeft(tankman)
            return self.fix_number(result) if result > 0 else 1
        else:
            avgXp = float(g_itemsCache.items.getTankmanDossier(tankman.invID).getAvgXP())
            if avgXp > 0: return self.fix_number(math.ceil(tankman.getNextSkillXpCost()/avgXp))
            else: return 1
    
    def exp_step_battles(self, tankman):
        if tankman.isInTank:
            result = self.isInTank_getNextLevelBattlesLeft(tankman)
            return self.fix_number(result) if result > 0 else 1
        else:
            avgXp = float(g_itemsCache.items.getTankmanDossier(tankman.invID).getAvgXP())
            if avgXp > 0: return self.fix_number(math.ceil(tankman.getNextLevelXpCost()/avgXp))
            else: return 1

    def create_format_str(self, id, tankman):
        if id not in data.tankman_hangar:
            data.tankman_hangar[id] = {}
            data.tankman_hangar[id]['xp'] = 0
        update = False
        if data.tankman_hangar[id]['xp'] < tankman.descriptor.totalXP():
            update = True
        data.tankman_hangar[id]['xp'] = tankman.descriptor.totalXP()
        format_str = {}
        if self.check_macros('{training-level}'):
            if 'training-level' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['raining-level'] = '%s' %tankman.realRoleLevel[0]
            format_str['training-level'] = data.tankman_hangar[id]['raining-level']
        if self.check_macros('{basic-training-level}'):
            if 'basic-training-level' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['basic-training-level'] = '%s' %tankman.efficiencyRoleLevel
            format_str['basic-training-level'] = data.tankman_hangar[id]['basic-training-level']
        if self.check_macros('{firstname}'):
            if 'firstname' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['firstname'] = '%s' %tankman.firstUserName
            format_str['firstname'] = data.tankman_hangar[id]['firstname']
        if self.check_macros('{lastname}'):
            if 'lastname' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['lastname'] = '%s' %tankman.lastUserName
            format_str['lastname'] = data.tankman_hangar[id]['lastname']
        if self.check_macros('{rank}'):
            if 'rank' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['rank'] = '%s' %tankman.rankUserName
            format_str['rank'] = data.tankman_hangar[id]['rank']
        if self.check_macros('{exp-total}'):
            if 'exp-total' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['exp-total'] = '%s' %self.fix_number(tankman.getNextSkillXpCost() + tankman.descriptor.freeXP)
            format_str['exp-total'] = data.tankman_hangar[id]['exp-total']
        if self.check_macros('{training-battles}'):
            if 'training-battles' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['training-battles'] = '%s' %self.training_battles(tankman)
            format_str['training-battles'] = data.tankman_hangar[id]['training-battles']
        if self.check_macros('{nxtskillvlv}'):
            if 'nxtskillvlv' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['nxtskillvlv'] = '%s' %((tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]) + 1
            format_str['nxtskillvlv'] = data.tankman_hangar[id]['nxtskillvlv']
        if self.check_macros('{skillsCnt}'):
            if 'skillsCnt' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['skillsCnt'] = '%s' %tankman.descriptor.lastSkillNumber if not tankman.hasNewSkill else tankman.descriptor.lastSkillNumber + tankman.newSkillCount[0]
            format_str['skillsCnt'] = data.tankman_hangar[id]['skillsCnt']
        if self.check_macros('{training-progress}'):
            if 'training-progress' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['training-progress'] = '%s' %(tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]
            format_str['training-progress'] = data.tankman_hangar[id]['training-progress']
        if self.check_macros('{role}'):
            if 'role' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['role'] = '%s' %tankman.roleUserName
            format_str['role'] = data.tankman_hangar[id]['role']
        if self.check_macros('{curexp}'):
            if 'curexp' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['curexp'] = '%s' %self.fix_number(tankman.descriptor.totalXP())
            format_str['curexp'] = data.tankman_hangar[id]['curexp']
        if self.check_macros('{vehicleType}'):
            if 'vehicleType' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['vehicleType'] = '%s' %g_itemsCache.items.getItemByCD(tankman.vehicleNativeDescr.type.compactDescr).shortUserName
            format_str['vehicleType'] = data.tankman_hangar[id]['vehicleType']
        if self.check_macros('{exp-step}'):
            if 'exp-step' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['exp-step'] = '%s' %self.fix_number(tankman.getNextLevelXpCost())
            format_str['exp-step'] = data.tankman_hangar[id]['exp-step']
        if self.check_macros('{exp-step-battles}'):
            if 'exp-step-battles' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['exp-step-battles'] = '%s' %self.exp_step_battles(tankman)
            format_str['exp-step-battles'] = data.tankman_hangar[id]['exp-step-battles']
        if self.check_macros('{exp-free}'):
            if 'exp-free' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['exp-free'] = '%s' %self.fix_number(tankman.descriptor.freeXP)
            format_str['exp-free'] = data.tankman_hangar[id]['exp-free']
        if self.check_macros('{lastSkillLevel}'):
            if 'lastSkillLevel' not in data.tankman_hangar[id] or update: data.tankman_hangar[id]['lastSkillLevel'] = '%s' %tankman.descriptor.lastSkillLevel
            format_str['lastSkillLevel'] = data.tankman_hangar[id]['lastSkillLevel']
        return format_str

    def change_data(self, data):
        for tankmenData in data['tankmen']:
            tankman = g_itemsCache.items.getTankman(tankmenData['tankmanID'])
            id = tankmenData['tankmanID']
            format_str = self.create_format_str(id, tankman)
            tankmenData['lastName'] = config._language['hangar_crew']['lastname_string'].format(**format_str)
            tankmenData['firstName'] = config._language['hangar_crew']['firstname_string'].format(**format_str)
            tankmenData['role'] = config._language['hangar_crew']['role_string'].format(**format_str)
            tankmenData['vehicleType'] = config._language['hangar_crew']['vehicletype_string'].format(**format_str)
            tankmenData['rank'] = config._language['hangar_crew']['rank_string'].format(**format_str)
        return data

class Temp_data(object):
    def __init__(self):
        self.tankman_hangar = {}
        self.tankman_barracks = {}

class Barracks_crew(object):

    @staticmethod
    def get_skill_icons(tankman):
        skillicons = ''
        for skill in tankman.skills:
            skillicons += "<img src='img://gui/maps/icons/tankmen/skills/small/%s' width='14' height='14' align='baseline' vspace='-3'>" %(skill.icon)
        if tankman.hasNewSkill:
            skillicons += "<img src='img://gui/maps/icons/tankmen/skills/small/new_skill.png' width='14' height='14' align='baseline' vspace='-3'>"
        return skillicons
    
    @staticmethod
    def check_macros(macros):
        if macros in config._language['barracks_crew']['firstname_string']: return True
        if macros in config._language['barracks_crew']['lastname_string']: return True
        if macros in config._language['barracks_crew']['role_string']: return True
        if macros in config._language['barracks_crew']['vehicletype_string']: return True
        if macros in config._language['barracks_crew']['rank_string']: return True
        return False
    
    def create_format_str(self, id, tankman):
        if id not in data.tankman_barracks:
            data.tankman_barracks[id] = {}
            data.tankman_barracks[id]['curexp'] = 0
        update = False
        if data.tankman_barracks[id]['curexp'] < tankman.descriptor.totalXP(): update = True
        format_str = {}
        if self.check_macros('{training-level}'):
            if 'training-level' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['raining-level'] = '%s' %tankman.realRoleLevel[0]
            format_str['training-level'] = data.tankman_barracks[id]['raining-level']
        if self.check_macros('{basic-training-level}'):
            if 'basic-training-level' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['basic-training-level'] = '%s' %tankman.efficiencyRoleLevel
            format_str['basic-training-level'] = data.tankman_barracks[id]['basic-training-level']
        if self.check_macros('{firstname}'):
            if 'firstname' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['firstname'] = '%s' %tankman.firstUserName
            format_str['firstname'] = data.tankman_barracks[id]['firstname']
        if self.check_macros('{lastname}'):
            if 'lastname' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['lastname'] = '%s' %tankman.lastUserName
            format_str['lastname'] = data.tankman_barracks[id]['lastname']
        if self.check_macros('{rank}'):
            if 'rank' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['rank'] = '%s' %tankman.rankUserName
            format_str['rank'] = data.tankman_barracks[id]['rank']
        if self.check_macros('{exp-total}'):
            if 'exp-total' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['exp-total'] = '%s' %hangar_crew.fix_number(tankman.getNextSkillXpCost() + tankman.descriptor.freeXP)
            format_str['exp-total'] = data.tankman_barracks[id]['exp-total']
        if self.check_macros('{training-battles}'):
            if 'training-battles' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['training-battles'] = '%s' %hangar_crew.training_battles(tankman)
            format_str['training-battles'] = data.tankman_barracks[id]['training-battles']
        if self.check_macros('{nxtskillvlv}'):
            if 'nxtskillvlv' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['nxtskillvlv'] = '%s' %((tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]) + 1
            format_str['nxtskillvlv'] = data.tankman_barracks[id]['nxtskillvlv']
        if self.check_macros('{skillsCnt}'):
            if 'skillsCnt' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['skillsCnt'] = '%s' %tankman.descriptor.lastSkillNumber if not tankman.hasNewSkill else tankman.descriptor.lastSkillNumber + tankman.newSkillCount[0]
            format_str['skillsCnt'] = data.tankman_barracks[id]['skillsCnt']
        if self.check_macros('{training-progress}'):
            if 'training-progress' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['training-progress'] = '%s' %(tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]
            format_str['training-progress'] = data.tankman_barracks[id]['training-progress']
        if self.check_macros('{role}'):
            if 'role' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['role'] = '%s' %tankman.roleUserName
            format_str['role'] = data.tankman_barracks[id]['role']
        if self.check_macros('{curexp}'):
            if 'curexp' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['curexp'] = '%s' %hangar_crew.fix_number(tankman.descriptor.totalXP())
            format_str['curexp'] = data.tankman_barracks[id]['curexp']
        if self.check_macros('{vehicleType}'):
            if 'vehicleType' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['vehicleType'] = '%s' %g_itemsCache.items.getItemByCD(tankman.vehicleNativeDescr.type.compactDescr).shortUserName
            format_str['vehicleType'] = data.tankman_barracks[id]['vehicleType']
        if self.check_macros('{exp-step}'):
            if 'exp-step' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['exp-step'] = '%s' %hangar_crew.fix_number(tankman.getNextLevelXpCost())
            format_str['exp-step'] = data.tankman_barracks[id]['exp-step']
        if self.check_macros('{exp-step-battles}'):
            if 'exp-step-battles' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['exp-step-battles'] = '%s' %hangar_crew.exp_step_battles(tankman)
            format_str['exp-step-battles'] = data.tankman_barracks[id]['exp-step-battles']
        if self.check_macros('{exp-free}'):
            if 'exp-free' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['exp-free'] = '%s' %hangar_crew.fix_number(tankman.descriptor.freeXP)
            format_str['exp-free'] = data.tankman_barracks[id]['exp-free']
        if self.check_macros('{lastSkillLevel}'):
            if 'lastSkillLevel' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['lastSkillLevel'] = '%s' %tankman.descriptor.lastSkillLevel
            format_str['lastSkillLevel'] = data.tankman_barracks[id]['lastSkillLevel']
        if self.check_macros('{skillicons}'):
            if 'skillicons' not in data.tankman_barracks[id] or update: data.tankman_barracks[id]['skillicons'] = '%s' %self.get_skill_icons(tankman)
            format_str['skillicons'] = data.tankman_barracks[id]['skillicons']
        return format_str
    
    def change_data(self, data):
        for tankmenData in data:
            if 'tankmanID' in tankmenData:
                tankman = g_itemsCache.items.getTankman(int(tankmenData['tankmanID']))
                id = tankmenData['tankmanID']
                format_str = self.create_format_str(id, tankman)
                tankmenData['lastname'] = config._language['barracks_crew']['lastname_string'].format(**format_str)
                tankmenData['firstname'] = config._language['barracks_crew']['firstname_string'].format(**format_str)
                tankmenData['role'] = config._language['barracks_crew']['role_string'].format(**format_str) if not config.XVMInstalled else tankmenData['role']
                tankmenData['vehicleType'] = config._language['barracks_crew']['vehicletype_string'].format(**format_str)
                tankmenData['rank'] = config._language['barracks_crew']['rank_string'].format(**format_str)
        return data


  

# deformated functions:
def hook_UpdateAll(self):
    hooked_UpdateAll(self)
    config.analitycs()

def hook_getStats(self,tankman):
    if config._enable:
        return personal_file.getStats(self, tankman, hooked_getStats(self, tankman))
    else: return hooked_getStats(self, tankman)

def hook_as_tankmenResponseS(self, data):
    if config._enable and config.data['config']['hangar_crew']:
        return hooked_as_tankmenResponseS(self,  hangar_crew.change_data(data))
    else: return hooked_as_tankmenResponseS(self, data)

def hook_as_setTankmenS_deprecated(self, tankmenCount, placesCount, tankmenInBarracks, tankmanArr):
    if config._enable and config.data['config']['barracks_crew']:
        return hooked_as_setTankmenS(self, tankmenCount, placesCount, tankmenInBarracks, barracks_crew.change_data(tankmanArr))
    return hooked_as_setTankmenS(self, tankmenCount, placesCount, tankmenInBarracks, tankmanArr)

def hook_as_setTankmenS(self, tankmenCount, tankmenInSlots, placesCount, tankmenInBarracks, tankmanArr):
    if config._enable and config.data['config']['barracks_crew']:

        return hooked_as_setTankmenS(self, tankmenCount, tankmenInSlots, placesCount, tankmenInBarracks, barracks_crew.change_data(tankmanArr))
    return hooked_as_setTankmenS(self, tankmenCount, tankmenInSlots, placesCount, tankmenInBarracks, tankmanArr)



#hooked
hooked_UpdateAll = Hangar._Hangar__updateAll
hooked_getStats = TankmanDossier.getStats
hooked_as_tankmenResponseS = CrewMeta.as_tankmenResponseS
hooked_as_setTankmenS = BarracksMeta.as_setTankmenS

#hook
Hangar._Hangar__updateAll = hook_UpdateAll
TankmanDossier.getStats = hook_getStats
CrewMeta.as_tankmenResponseS = hook_as_tankmenResponseS
if BigWorld.wg_getProductVersion() == '0, 9, 8, 0': BarracksMeta.as_setTankmenS = hook_as_setTankmenS_deprecated
else: BarracksMeta.as_setTankmenS = hook_as_setTankmenS




#start mod
personal_file = Personal_file()
hangar_crew = Hangar_crew()
barracks_crew = Barracks_crew()
config = Config()
config.load_mod()
data = Temp_data()
