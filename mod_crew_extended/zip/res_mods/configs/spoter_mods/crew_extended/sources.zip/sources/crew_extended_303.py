﻿# -*- coding: utf-8 -*- 
import BigWorld
import ResMgr
import datetime
import cProfile
from debug_utils import FLUSH_LOG
import math
#
#from helpers import i18n
#from gui.Scaleform.locale.MENU import MENU

from gui.shared.gui_items.dossier import TankmanDossier
from helpers.i18n import makeString
from items.tankmen import MAX_SKILL_LEVEL
from math import ceil, floor, log10
from helpers.i18n import convert
from gui.Scaleform.Waiting import Waiting
from CurrentVehicle import g_currentVehicle
from gui.shared import events, g_itemsCache
from gui.Scaleform.daapi.view.lobby.hangar.Crew import Crew
from items.tankmen import getSkillsConfig, compareMastery, ACTIVE_SKILLS
from gui.shared.gui_items import Tankman
BigWorld.module_crew_extended = True
BigWorld.crew_extended_settings = {'getStatsCrewselSelfId': None,
                                   'Profile': cProfile.Profile(),
                                   'debug': False,
                                   'hangar_crew_info': True,
                                   'barracks_crew_info': True,
                                   'language': 'EN',
                                   'txt_premium_bonus_on': u'Premium bonus for exp: Enabled',
                                   'txt_premium_bonus_off': u'Premium bonus for exp: Disabled',
                                   'txt_up_to_exp': u'Experience to',
                                   'txt_up_to_battle': u'Battles to',
                                   'txt_skill_number': u'Skill',
                                   'txt_basic_skill': u'Basic skill',
                                   'txt_SilverReLearn': u'Retraining',
                                   'txt_SilverReLearn_need': u'for credits need',
                                   'txt_SilverReLearn_ready': u'for credits ready!',
                                   'txt_SilverReLearn_notready': u'for credits not ready',
                                   'txt_hangar_specializationLevel': u'{training-level}',
                                   'txt_hangar_rank': u'[{exp-step-battles}\{exp-step}] {rank}',
                                   'txt_hangar_lastname': u'{lastname}',
                                   'txt_hangar_colored_lastskilllevel': u'{lastSkillLevel}',
                                   'txt_hangar_firstname': u'{firstname}',
                                   'txt_hangar_colored_role': u'[<font color="#00FF00">{training-battles}</font>\<font color="#FFFF00">{exp-total}</font>]{role}',
                                   'txt_hangar_colored_vehicletype': u'{vehicleType}',
                                   'txt_barracks_firstname': u'[{exp-step-battles}\{exp-step}] {firstname}',
                                   'txt_barracks_lastname': u'{lastname}',
                                   'txt_barracks_rank': u'{role}',
                                   'txt_barracks_colored_role': u'[<font color="#00FF00">{training-battles}</font>\<font color="#FFFF00">{exp-total}</font>] {skillicons}',
                                   'txt_barracks_colored_vehicleType': u'{vehicleType}',
                                   'txt_barracks_lockMessage': u'{lockMessage}',
                                   'XML': ResMgr.openSection('scripts/client/mods/crew_extended.xml', True),
                                  }
BigWorld.crew_extended_data = {}

description = 'crew extended'
version = 'v3.03 (08/03/2015)'
author = 'by spoter'

def hook_profiler(name, status, debug = False):
    if BigWorld.crew_extended_settings['debug'] or debug:
        if status:
            debugs(str(name.__name__)+' dump stat started:')
            BigWorld.crew_extended_settings['Profile'].enable()
        else:
            profile_filename = name.__name__ + '.prof'
            BigWorld.crew_extended_settings['Profile'].create_stats()
            #BigWorld.crew_extended_settings['Profile'].dump_stats(profile_filename)
            BigWorld.crew_extended_settings['Profile'].print_stats()
            BigWorld.crew_extended_settings['Profile'].clear()
            debugs(str(name.__name__)+' dump stat end:')
            FLUSH_LOG()

def debugs(text):
    if BigWorld.crew_extended_settings['debug']:
        timesht=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print '['+str(timesht)+'][DEBUG]['+description+']: [ '+str(text)+' ]'
        FLUSH_LOG()


def Init():
    print ''
    print '[LOAD_MOD]:  ['+str(description)+' '+str(author)+']'
    if not BigWorld.crew_extended_settings['XML']:
        print '[INFO]:     XML not found, recreating'
        BigWorld.crew_extended_settings['XML'].write('setup', '')
        BigWorld.crew_extended_settings['XML']['setup'].writeBool('module_crew_extended' , BigWorld.module_crew_extended)
        BigWorld.crew_extended_settings['XML']['setup'].writeBool('debug' , BigWorld.crew_extended_settings['debug'])
        BigWorld.crew_extended_settings['XML']['setup'].writeBool('hangar_crew_info' , BigWorld.crew_extended_settings['hangar_crew_info'])
        BigWorld.crew_extended_settings['XML']['setup'].writeBool('barracks_crew_info' , BigWorld.crew_extended_settings['barracks_crew_info'])
        BigWorld.crew_extended_settings['XML']['setup'].writeString('language' , BigWorld.crew_extended_settings['language'])
        BigWorld.crew_extended_settings['XML']['setup'].writeString('hint' , 'support language RU,EN,DE,OTHER')
        BigWorld.crew_extended_settings['XML'].write('hangar_crew_info', '')
        BigWorld.crew_extended_settings['XML']['hangar_crew_info'].writeString('txt_hangar_firstname' , BigWorld.crew_extended_settings['txt_hangar_firstname'])
        BigWorld.crew_extended_settings['XML']['hangar_crew_info'].writeString('txt_hangar_lastname' , BigWorld.crew_extended_settings['txt_hangar_lastname'])
        BigWorld.crew_extended_settings['XML']['hangar_crew_info'].writeString('txt_hangar_rank' , BigWorld.crew_extended_settings['txt_hangar_rank'])
        BigWorld.crew_extended_settings['XML']['hangar_crew_info'].writeString('txt_hangar_colored_lastskilllevel' , BigWorld.crew_extended_settings['txt_hangar_colored_lastskilllevel'])
        BigWorld.crew_extended_settings['XML']['hangar_crew_info'].writeString('txt_hangar_specializationLevel' , BigWorld.crew_extended_settings['txt_hangar_specializationLevel'])
        BigWorld.crew_extended_settings['XML']['hangar_crew_info'].writeString('txt_hangar_colored_role' , BigWorld.crew_extended_settings['txt_hangar_colored_role'])
        BigWorld.crew_extended_settings['XML']['hangar_crew_info'].writeString('txt_hangar_colored_vehicletype' , BigWorld.crew_extended_settings['txt_hangar_colored_vehicletype'])
        BigWorld.crew_extended_settings['XML']['hangar_crew_info'].writeString('hint' , 'support macros in txt: {training-level},{firstname},{lastname},{rank},{exp-total},{training-battles},{training-progress},{role},{CurExp},{vehicleType},{exp-step},{exp-step-battles},{exp-extra-level},{exp-free},{skillsCnt},{lastSkillLevel},{nxtskillvlv},{training-level-int},{exp-total-int},{training-battles-int},{nxtskillvlv-int},{skillsCnt-int},{training-progress-int}, {CurExp-int},{exp-step-int}, {exp-step-battles-int},{exp-extra-level-int},{exp-free-int},{lastSkillLevel-int}')
        BigWorld.crew_extended_settings['XML'].write('barracks_crew_info', '')
        BigWorld.crew_extended_settings['XML']['barracks_crew_info'].writeString('txt_barracks_firstname' , BigWorld.crew_extended_settings['txt_barracks_firstname'])
        BigWorld.crew_extended_settings['XML']['barracks_crew_info'].writeString('txt_barracks_lastname' , BigWorld.crew_extended_settings['txt_barracks_lastname'])
        BigWorld.crew_extended_settings['XML']['barracks_crew_info'].writeString('txt_barracks_rank' , BigWorld.crew_extended_settings['txt_barracks_rank'])
        BigWorld.crew_extended_settings['XML']['barracks_crew_info'].writeString('txt_barracks_colored_role' , BigWorld.crew_extended_settings['txt_barracks_colored_role'])
        BigWorld.crew_extended_settings['XML']['barracks_crew_info'].writeString('txt_barracks_colored_vehicleType' , BigWorld.crew_extended_settings['txt_barracks_colored_vehicleType'])
        BigWorld.crew_extended_settings['XML']['barracks_crew_info'].writeString('txt_barracks_lockMessage' , BigWorld.crew_extended_settings['txt_barracks_lockMessage'])
        BigWorld.crew_extended_settings['XML']['barracks_crew_info'].writeString('hint' , 'support macros in txt: {skillicons},{lockMessage},{training-level},{firstname},{lastname},{rank},{exp-total},{training-battles},{training-progress},{role},{CurExp},{vehicleType},{exp-step},{exp-step-battles},{exp-extra-level},{exp-free},{skillsCnt},{lastSkillLevel},{nxtskillvlv},{training-level-int},{exp-total-int},{training-battles-int},{nxtskillvlv-int},{skillsCnt-int},{training-progress-int}, {CurExp-int},{exp-step-int}, {exp-step-battles-int},{exp-extra-level-int},{exp-free-int},{lastSkillLevel-int}')
        BigWorld.crew_extended_settings['XML'].write('other_language', '')
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_premium_bonus_on' , '')
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_premium_bonus_on' , BigWorld.crew_extended_settings['txt_premium_bonus_on'])
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_premium_bonus_off' , BigWorld.crew_extended_settings['txt_premium_bonus_off'])
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_up_to_exp' , BigWorld.crew_extended_settings['txt_up_to_exp'])
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_up_to_battle' , BigWorld.crew_extended_settings['txt_up_to_battle'])
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_skill_number' , BigWorld.crew_extended_settings['txt_skill_number'])
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_basic_skill' , BigWorld.crew_extended_settings['txt_basic_skill'])
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_SilverReLearn' , BigWorld.crew_extended_settings['txt_SilverReLearn'])
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_SilverReLearn_need' , BigWorld.crew_extended_settings['txt_SilverReLearn_need'])
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_SilverReLearn_ready' , BigWorld.crew_extended_settings['txt_SilverReLearn_ready'])
        BigWorld.crew_extended_settings['XML']['other_language'].writeString('txt_SilverReLearn_notready' , BigWorld.crew_extended_settings['txt_SilverReLearn_notready'])
        BigWorld.crew_extended_settings['XML'].save()
        print '[INFO]:     XML recreating DONE'
    BigWorld.module_crew_extended = BigWorld.crew_extended_settings['XML']['setup'].readBool('module_crew_extended')
    if BigWorld.module_crew_extended:
        print '[INFO]:      ['+str(description)+' '+str(version)+' initialized ...]'
        BigWorld.crew_extended_settings['debug'] = BigWorld.crew_extended_settings['XML']['setup'].readBool('debug')
        BigWorld.crew_extended_settings['language'] = BigWorld.crew_extended_settings['XML']['setup'].readString('language')
        BigWorld.crew_extended_settings['hangar_crew_info'] = BigWorld.crew_extended_settings['XML']['setup'].readBool('hangar_crew_info')
        BigWorld.crew_extended_settings['barracks_crew_info'] = BigWorld.crew_extended_settings['XML']['setup'].readBool('barracks_crew_info')
        if BigWorld.crew_extended_settings['language'] == 'RU':
            print '[INFO]:      [ExtendedCrew Language set to : "RUSSIAN"...]'
            BigWorld.crew_extended_settings['txt_premium_bonus_on'] = u'Премиум бонус на опыт: Активирован'
            BigWorld.crew_extended_settings['txt_premium_bonus_off'] = u'Премиум бонус на опыт: Неактивен'
            BigWorld.crew_extended_settings['txt_up_to_exp'] = u'Опыта до'
            BigWorld.crew_extended_settings['txt_up_to_battle'] = u'Боёв до'
            BigWorld.crew_extended_settings['txt_skill_number'] = u'Навык'
            BigWorld.crew_extended_settings['txt_basic_skill'] = u'Базовый навык'
            BigWorld.crew_extended_settings['txt_SilverReLearn'] = u'Переобучение'
            BigWorld.crew_extended_settings['txt_SilverReLearn_need'] = u'за кредиты надо'
            BigWorld.crew_extended_settings['txt_SilverReLearn_ready'] = u'за кредиты Готово!'
            BigWorld.crew_extended_settings['txt_SilverReLearn_notready'] = u'за кредиты не доступно'
        elif BigWorld.crew_extended_settings['language'] == 'DE':
            print '[INFO]:      [ExtendedCrew Language set to : "GERMAN"...]'
            BigWorld.crew_extended_settings['txt_premium_bonus_on'] = u'Premienbonus Erfahrung: aktiviert'
            BigWorld.crew_extended_settings['txt_premium_bonus_off'] = u'Premienbonus Erfahrung: deaktiviert'
            BigWorld.crew_extended_settings['txt_up_to_exp'] = u'Erfahrung bis'
            BigWorld.crew_extended_settings['txt_up_to_battle'] = u'Gefechte bis'
            BigWorld.crew_extended_settings['txt_skill_number'] = u'Fertigkeit'
            BigWorld.crew_extended_settings['txt_basic_skill'] = u'Grundperk'
            BigWorld.crew_extended_settings['txt_SilverReLearn'] = u'Umschulung'
            BigWorld.crew_extended_settings['txt_SilverReLearn_need'] = u'f'+unichr(252)+'r Kredits ben. '
            BigWorld.crew_extended_settings['txt_SilverReLearn_ready'] = u'f'+unichr(252)+'r Kredits bereit!'
            BigWorld.crew_extended_settings['txt_SilverReLearn_notready'] = u'f'+unichr(252)+'r Kredits nicht verf'+unichr(252)+'gbar '
        elif BigWorld.crew_extended_settings['language'] == 'OTHER':
            print '[INFO]:      [ExtendedCrew Language set to : "OTHER". Uses custom strings from XML file in section "OtherLanguage"...]'
            BigWorld.crew_extended_settings['txt_premium_bonus_on'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_premium_bonus_on')
            BigWorld.crew_extended_settings['txt_premium_bonus_off'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_premium_bonus_off')
            BigWorld.crew_extended_settings['txt_up_to_exp'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_up_to_exp')
            BigWorld.crew_extended_settings['txt_up_to_battle'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_up_to_battle')
            BigWorld.crew_extended_settings['txt_skill_number'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_skill_number')
            BigWorld.crew_extended_settings['txt_basic_skill'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_basic_skill')
            BigWorld.crew_extended_settings['txt_SilverReLearn'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_SilverReLearn')
            BigWorld.crew_extended_settings['txt_SilverReLearn_need'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_SilverReLearn_need')
            BigWorld.crew_extended_settings['txt_SilverReLearn_ready'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_SilverReLearn_ready')
            BigWorld.crew_extended_settings['txt_SilverReLearn_notready'] = BigWorld.crew_extended_settings['XML']['other_language'].readString('txt_SilverReLearn_notready')
        elif BigWorld.crew_extended_settings['language'] == 'EN':
            print '[INFO]:      [ExtendedCrew Language set to : "ENGLISH"...]'
        else:
            print '[WARNING]:      [ExtendedCrew XML Error ! Language set to : ENGLISH]'
        if BigWorld.crew_extended_settings['hangar_crew_info']:
            BigWorld.crew_extended_settings['txt_hangar_specializationLevel'] = BigWorld.crew_extended_settings['XML']['hangar_crew_info'].readString('txt_hangar_specializationLevel')
            BigWorld.crew_extended_settings['txt_hangar_rank'] = BigWorld.crew_extended_settings['XML']['hangar_crew_info'].readString('txt_hangar_rank')
            BigWorld.crew_extended_settings['txt_hangar_lastname'] = BigWorld.crew_extended_settings['XML']['hangar_crew_info'].readString('txt_hangar_lastname')
            BigWorld.crew_extended_settings['txt_hangar_colored_lastskilllevel'] = BigWorld.crew_extended_settings['XML']['hangar_crew_info'].readString('txt_hangar_colored_lastskilllevel')
            BigWorld.crew_extended_settings['txt_hangar_firstname'] = BigWorld.crew_extended_settings['XML']['hangar_crew_info'].readString('txt_hangar_firstname')
            BigWorld.crew_extended_settings['txt_hangar_colored_role'] = BigWorld.crew_extended_settings['XML']['hangar_crew_info'].readString('txt_hangar_colored_role')
            BigWorld.crew_extended_settings['txt_hangar_colored_vehicletype'] = BigWorld.crew_extended_settings['XML']['hangar_crew_info'].readString('txt_hangar_colored_vehicletype')
        if BigWorld.crew_extended_settings['barracks_crew_info']:
            BigWorld.crew_extended_settings['txt_barracks_firstname']= BigWorld.crew_extended_settings['XML']['barracks_crew_info'].readString('txt_barracks_firstname')
            BigWorld.crew_extended_settings['txt_barracks_lastname']= BigWorld.crew_extended_settings['XML']['barracks_crew_info'].readString('txt_barracks_lastname')
            BigWorld.crew_extended_settings['txt_barracks_rank']= BigWorld.crew_extended_settings['XML']['barracks_crew_info'].readString('txt_barracks_rank')
            BigWorld.crew_extended_settings['txt_barracks_colored_role']= BigWorld.crew_extended_settings['XML']['barracks_crew_info'].readString('txt_barracks_colored_role')
            BigWorld.crew_extended_settings['txt_barracks_colored_vehicleType']= BigWorld.crew_extended_settings['XML']['barracks_crew_info'].readString('txt_barracks_colored_vehicleType')
            BigWorld.crew_extended_settings['txt_barracks_lockMessage']= BigWorld.crew_extended_settings['XML']['barracks_crew_info'].readString('txt_barracks_lockMessage')
        if BigWorld.crew_extended_settings['debug']:
            debugs(str(description)+' Debug Activated ...')
        #if BigWorld.wg_getProductVersion() != '0, 9, 5, 0':
        TankmanDossier.getStats = new_getStatsCrew
        Crew.updateTankmen = new_updateTankmenAvgXP
    else:
        print '[INFO]:      ['+str(description)+' '+str(version)+' disabled ...]'
    print ''

def new_getStatsCrew(self, tankman):
    if BigWorld.crew_extended_settings['debug']:
        hook_profiler(new_getStatsCrew,True)
    BigWorld.crew_extended_settings['getStatsCrewselSelfId'] = self
    imageType, image = self._TankmanDossier__getCurrentSkillIcon()
    if tankman.invID not in BigWorld.crew_extended_data:
        BigWorld.crew_extended_data[tankman.invID] = {}
        #BigWorld.crew_extended_data[tankman.invID]['tankman'] = tankman
        BigWorld.crew_extended_data[tankman.invID]['totalXP'] = (tankman.descriptor.totalXP(),millifyAvgXP(tankman.descriptor.totalXP()))
        BigWorld.crew_extended_data[tankman.invID]['BattlesCount'] = (self.getBattlesCount(),millifyAvgXP(self.getBattlesCount()))
        BigWorld.crew_extended_data[tankman.invID]['AvgXP'] = (self.getAvgXP(),millifyAvgXP(self.getAvgXP()))
        BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl'] = ((tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]) + 1
        BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'] = tankman.descriptor.lastSkillNumber if not tankman.hasNewSkill else tankman.descriptor.lastSkillNumber+tankman.newSkillCount[0]
        BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel'] = (tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]
        BigWorld.crew_extended_data[tankman.invID]['freeXP'] = (tankman.descriptor.freeXP,millifyAvgXP(tankman.descriptor.freeXP))
        BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'] = (getNextLevelXpCost(tankman),millifyAvgXP(getNextLevelXpCost(tankman)))
        BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'] = (getLastLevelXpCost(tankman),millifyAvgXP(getLastLevelXpCost(tankman)))
        BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'] = (getNextSkillBattlesLeft(self, tankman),millifyAvgXP(getNextSkillBattlesLeft(self, tankman)))
        BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'] = (getLastSkillBattlesLeft(self, tankman),millifyAvgXP(getLastSkillBattlesLeft(self, tankman)))
        tmp1,tmp2 = __checkSilverLearn(tankman)
        BigWorld.crew_extended_data[tankman.invID]['SilverLearn'] = (tmp1,tmp2,millifyAvgXP(tmp2))
    if self.tmanDescr.totalXP() > BigWorld.crew_extended_data[tankman.invID]['totalXP'][0]:
        #print(str(tankman.invID)+' exp changed to '+str(self.tmanDescr.totalXP() - BigWorld.crew_extended_data[tankman.invID]['totalXP'][0]))
        #BigWorld.crew_extended_data[tankman.invID]['tankman'] = tankman
        BigWorld.crew_extended_data[tankman.invID]['totalXP'] = (tankman.descriptor.totalXP(),millifyAvgXP(tankman.descriptor.totalXP()))
        BigWorld.crew_extended_data[tankman.invID]['BattlesCount'] = (self.getBattlesCount(),millifyAvgXP(self.getBattlesCount()))
        BigWorld.crew_extended_data[tankman.invID]['AvgXP'] = (self.getAvgXP(),millifyAvgXP(self.getAvgXP()))
        BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl'] = ((tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]) + 1
        BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'] = tankman.descriptor.lastSkillNumber if not tankman.hasNewSkill else tankman.descriptor.lastSkillNumber+tankman.newSkillCount[0]
        BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel'] = (tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]
        BigWorld.crew_extended_data[tankman.invID]['freeXP'] = (tankman.descriptor.freeXP,millifyAvgXP(tankman.descriptor.freeXP))
        BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'] = (getNextLevelXpCost(tankman),millifyAvgXP(getNextLevelXpCost(tankman)))
        BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'] = (getLastLevelXpCost(tankman),millifyAvgXP(getLastLevelXpCost(tankman)))
        BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'] = (getNextSkillBattlesLeft(self, tankman),millifyAvgXP(getNextSkillBattlesLeft(self, tankman)))
        BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'] = (getLastSkillBattlesLeft(self, tankman),millifyAvgXP(getLastSkillBattlesLeft(self, tankman)))
        tmp1,tmp2 = __checkSilverLearn(tankman)
        BigWorld.crew_extended_data[tankman.invID]['SilverLearn'] = (tmp1,tmp2,millifyAvgXP(tmp2))
    if BigWorld.crew_extended_settings['debug']:
        hook_profiler(new_getStatsCrew,False)
    return (
            {'label': 'common', 
             'stats': (
                        {'name': 'battlesCount', 'value': self._TankmanDossier__formatValueForUI(BigWorld.crew_extended_data[tankman.invID]['BattlesCount'][0]), 'premiumValue': '', 'imageType': None, 'image': None}, 
                        {'name': 'avgExperience', 'value': self._TankmanDossier__formatValueForUI(BigWorld.crew_extended_data[tankman.invID]['AvgXP'][0]), 'premiumValue': '', 'imageType': None, 'image': None},
                        {'name': 'xp', 'value':  self._TankmanDossier__formatValueForUI(BigWorld.crew_extended_data[tankman.invID]['totalXP'][0]), 'premiumValue': '', 'imageType': imageType if not tankman.hasNewSkill else None, 'image': image if not tankman.hasNewSkill else None},
                        {'name': 'ready', 'value': (str(BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber']) if not tankman.hasNewSkill else str(tankman.descriptor.lastSkillNumber)+'('+str(BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'])+')') + ' ' + BigWorld.crew_extended_settings['txt_skill_number'] if self.tmanDescr.roleLevel == MAX_SKILL_LEVEL else BigWorld.crew_extended_settings['txt_basic_skill'], 'premiumValue': '', 'imageType': None, 'image': None}
                      )},
            {'label': 'studying',
            'secondLabel': '['+description+' '+version+'] '+BigWorld.crew_extended_settings['txt_premium_bonus_on'] +' (x'+str(self._TankmanDossier__currentVehicleCrewXpFactor)+')' if self._TankmanDossier__currentVehicleIsPremium else '['+description+' '+version+'] '+BigWorld.crew_extended_settings['txt_premium_bonus_off'],
            'isPremium': True,
             'stats': (
                        # опыта до 100% и до след уровная
                        {'name': 'empty', 'value': str(self._TankmanDossier__formatValueForUI(BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'][0])) + ' ' + str(BigWorld.crew_extended_settings['txt_up_to_exp'] + ' 100%'), 'premiumValue': str(self._TankmanDossier__formatValueForUI(BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'][0]))+' '+ str(BigWorld.crew_extended_settings['txt_up_to_exp'] + ' ' + str(BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl']) + '%' ), 'imageType': None, 'image': None},
                        # боев до 100% и до след уровная
                        {'name': 'empty', 'value': str(self._TankmanDossier__formatValueForUI(BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0])) + ' ' + str(BigWorld.crew_extended_settings['txt_up_to_battle'] + ' 100%'), 'premiumValue': str(self._TankmanDossier__formatValueForUI(BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0])) + ' ' + str(BigWorld.crew_extended_settings['txt_up_to_battle'] + ' ' + str(BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl']) + '%'), 'imageType': None, 'image': None},
                        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
                        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
                        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
                        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
                        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
                        {'name': 'ready', 'value': '', 'premiumValue': '', 'imageType': None if not tankman.hasNewSkill else imageType, 'image': None if not tankman.hasNewSkill else image},
                        {'name': 'empty', 'value': BigWorld.crew_extended_settings['txt_SilverReLearn'], 'premiumValue': BigWorld.crew_extended_settings['txt_SilverReLearn_ready'] if BigWorld.crew_extended_data[tankman.invID]['SilverLearn'][0] else BigWorld.crew_extended_settings['txt_SilverReLearn_notready'] if BigWorld.crew_extended_data[tankman.invID]['SilverLearn'][1] == 0  else BigWorld.crew_extended_settings['txt_SilverReLearn_need'] + ' ' + str(BigWorld.crew_extended_data[tankman.invID]['SilverLearn'][1]) + '%', 'imageType': None, 'image': None}
                        )})

def __checkSilverLearn(tankman):
    if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL and tankman.descriptor.lastSkillLevel == MAX_SKILL_LEVEL or tankman.hasNewSkill:
        nextSkillLevel = tankman.descriptor.lastSkillLevel
        skillSeqNum = 0
        if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL:
            skillSeqNum = tankman.descriptor.lastSkillNumber
        if tankman.hasNewSkill:
            skillSeqNum = BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber']
            nextSkillLevel = BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel']
        nextSkillLevel_orig = nextSkillLevel
        sum = tankman.descriptor.freeXP
        while sum <= 39153:
            sum += tankman.descriptor.levelUpXpCost(nextSkillLevel, skillSeqNum)
            nextSkillLevel += 1
        if nextSkillLevel_orig == nextSkillLevel:
            return (True,nextSkillLevel)
        else:
            return (False,nextSkillLevel)
    return (False,0)

def getNextLevelXpCost(tankman):
    if tankman.roleLevel != MAX_SKILL_LEVEL or (tankman.roleLevel == MAX_SKILL_LEVEL and not tankman.hasNewSkill):
        descr = tankman.descriptor
        if descr.lastSkillNumber == 0 or tankman.roleLevel != MAX_SKILL_LEVEL:
            nextSkillLevel = tankman.roleLevel
        else:
            nextSkillLevel = descr.lastSkillLevel
        skillSeqNum = 0
        if tankman.roleLevel == MAX_SKILL_LEVEL:
            skillSeqNum = descr.lastSkillNumber
        return descr.levelUpXpCost(nextSkillLevel, skillSeqNum) - descr.freeXP
    elif tankman.hasNewSkill:
        descr = tankman.descriptor
        skillSeqNum = BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber']
        nextSkillLevel = BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel']
        return descr.levelUpXpCost(nextSkillLevel, skillSeqNum) 
    return 0

def getLastLevelXpCost(tankman):
    if tankman.roleLevel != MAX_SKILL_LEVEL or (tankman.roleLevel == MAX_SKILL_LEVEL and not tankman.hasNewSkill):
        descr = tankman.descriptor
        if descr.lastSkillNumber == 0 or tankman.roleLevel != MAX_SKILL_LEVEL:
            nextSkillLevel = tankman.roleLevel
        else:
            nextSkillLevel = descr.lastSkillLevel
        skillSeqNum = 0
        if tankman.roleLevel == MAX_SKILL_LEVEL:
            skillSeqNum = descr.lastSkillNumber
        sum = -descr.freeXP
        while nextSkillLevel < MAX_SKILL_LEVEL:
            sum +=descr.levelUpXpCost(nextSkillLevel, skillSeqNum)
            nextSkillLevel += 1
        return sum
    elif tankman.hasNewSkill:
        descr = tankman.descriptor
        skillSeqNum = BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber']
        nextSkillLevel = BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel']
        sum = 0
        while nextSkillLevel < MAX_SKILL_LEVEL:
            sum +=descr.levelUpXpCost(nextSkillLevel, skillSeqNum)
            nextSkillLevel += 1
        return sum
    return 0

def getLastLevelXpCost_(self):
    descr = self.descriptor
    if descr.lastSkillNumber == 0 or self.roleLevel != MAX_SKILL_LEVEL:
        nextSkillLevel = self.roleLevel
    else:
        nextSkillLevel = descr.lastSkillLevel
    skillSeqNum = 0
    if self.roleLevel == MAX_SKILL_LEVEL:
        skillSeqNum = descr.lastSkillNumber
    if self.hasNewSkill:
        skillSeqNum = self.newSkillCount[1]+1
        nextSkillLevel = self.newSkillCount[0]+1
    sum = -descr.freeXP
    while nextSkillLevel < MAX_SKILL_LEVEL:
        sum +=descr.levelUpXpCost(nextSkillLevel, skillSeqNum)
        nextSkillLevel += 1
    return sum

def getLastSkillBattlesLeft(self, tankman):
    if not self.getBattlesCount() or not self.extStats.getBattlesCount() or not self.extStats.getXP():
        result = None
    else:
        avgExp = self.getAvgXP()
        if avgExp:
            result = max(1, math.ceil(getLastLevelXpCost(tankman) / avgExp))
        else:
            result = 0
    return result
    
def getNextSkillBattlesLeft(self, tankman):
    if not self.getBattlesCount() or not self.extStats.getBattlesCount() or not self.extStats.getXP():
        result = None
    else:
        avgExp = self.getAvgXP()
        newSkillReady = self.tmanDescr.roleLevel == MAX_SKILL_LEVEL and (len(self.tmanDescr.skills) == 0 or self.tmanDescr.lastSkillLevel == MAX_SKILL_LEVEL)
        if avgExp:
            result = max(1, math.ceil(getNextLevelXpCost(tankman) / avgExp))
        else:
            result = 0
    return result    

def new_updateTankmenAvgXP(self):
    if BigWorld.crew_extended_settings['debug']:
        hook_profiler(new_updateTankmenAvgXP,True)
    Waiting.show('updateTankmen')
    if g_currentVehicle.isPresent():
        tankmen = g_itemsCache.items.getTankmen()
        vehicle = g_currentVehicle.item
        commander_bonus = vehicle.bonuses['commander']
        roles = []
        lessMastered = 0
        tankmenDescrs = dict(vehicle.crew)
        for slotIdx, tman in vehicle.crew:
            if slotIdx > 0 and tman is not None and (tankmenDescrs[lessMastered] is None or compareMastery(tankmenDescrs[lessMastered].descriptor, tman.descriptor) > 0):
                lessMastered = slotIdx
            role = vehicle.descriptor.type.crewRoles[slotIdx][0]
            roles.append({'tankmanID': tman.invID if tman is not None else None,
             'roleType': role,
             'role': convert(getSkillsConfig()[role]['userString']),
             'roleIcon': Tankman.getRoleBigIconPath(role),
             'nationID': vehicle.nationID,
             'typeID': vehicle.innationID,
             'slot': slotIdx,
             'vehicleType': vehicle.shortUserName,
             'tankType': vehicle.type,
             'vehicleElite': vehicle.isPremium,
             'roles': list(vehicle.descriptor.type.crewRoles[slotIdx])})

        tankmenData = []
        for tankman in tankmen.itervalues():
            if tankman.isInTank and tankman.vehicleInvID != vehicle.invID:
                continue
            tankmanVehicle = g_itemsCache.items.getItemByCD(tankman.vehicleNativeDescr.type.compactDescr)
            bonus_role_level = commander_bonus if tankman.descriptor.role != 'commander' else 0.0
            skills_count = len(list(ACTIVE_SKILLS))
            skillsList = []
            for skill in tankman.skills:
                skillsList.append({'tankmanID': tankman.invID,
                 'id': str(tankman.skills.index(skill)),
                 'name': skill.userName,
                 'desc': skill.description,
                 'icon': skill.icon,
                 'level': skill.level,
                 'active': skill.isEnable and skill.isActive})

            newSkillsCount, lastNewSkillLvl = tankman.newSkillCount
            if newSkillsCount > 0:
                skillsList.append({'buy': True,
                 'tankmanID': tankman.invID,
                 'level': lastNewSkillLvl})
            if BigWorld.crew_extended_settings['hangar_crew_info']:
                if tankman.invID not in BigWorld.crew_extended_data:
                    extDossier = g_itemsCache.items.getTankmanDossier(tankman.invID)
                    BigWorld.crew_extended_data[tankman.invID] = {}
                    #BigWorld.crew_extended_data[tankman.invID]['tankman'] = tankman
                    BigWorld.crew_extended_data[tankman.invID]['totalXP'] = (tankman.descriptor.totalXP(),millifyAvgXP(tankman.descriptor.totalXP()))
                    BigWorld.crew_extended_data[tankman.invID]['BattlesCount'] = (extDossier.getBattlesCount(),millifyAvgXP(extDossier.getBattlesCount()))
                    BigWorld.crew_extended_data[tankman.invID]['AvgXP'] = (extDossier.getAvgXP(),millifyAvgXP(extDossier.getAvgXP()))
                    BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl'] = ((tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]) + 1
                    BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'] = tankman.descriptor.lastSkillNumber if not tankman.hasNewSkill else tankman.descriptor.lastSkillNumber+tankman.newSkillCount[0]
                    BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel'] = (tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]
                    BigWorld.crew_extended_data[tankman.invID]['freeXP'] = (tankman.descriptor.freeXP,millifyAvgXP(tankman.descriptor.freeXP))
                    BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'] = (getNextLevelXpCost(tankman),millifyAvgXP(getNextLevelXpCost(tankman)))
                    BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'] = (getLastLevelXpCost(tankman),millifyAvgXP(getLastLevelXpCost(tankman)))
                    BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'] = (getNextSkillBattlesLeft(extDossier, tankman),millifyAvgXP(getNextSkillBattlesLeft(extDossier, tankman)))
                    BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'] = (getLastSkillBattlesLeft(extDossier, tankman),millifyAvgXP(getLastSkillBattlesLeft(extDossier, tankman)))
                    tmp1,tmp2 = __checkSilverLearn(tankman)
                    BigWorld.crew_extended_data[tankman.invID]['SilverLearn'] = (tmp1,tmp2,millifyAvgXP(tmp2))
                if tankman.descriptor.totalXP() > BigWorld.crew_extended_data[tankman.invID]['totalXP']:
                    extDossier = g_itemsCache.items.getTankmanDossier(tankman.invID)
                    print(str(tankman.invID)+' exp changed to '+str(tankman.descriptor.totalXP() - BigWorld.crew_extended_data[tankman.invID]['totalXP'][0]))
                    BigWorld.crew_extended_data[tankman.invID]['totalXP'] = (tankman.descriptor.totalXP(),millifyAvgXP(tankman.descriptor.totalXP()))
                    BigWorld.crew_extended_data[tankman.invID]['BattlesCount'] = (extDossier.getBattlesCount(),millifyAvgXP(extDossier.getBattlesCount()))
                    BigWorld.crew_extended_data[tankman.invID]['AvgXP'] = (extDossier.getAvgXP(),millifyAvgXP(extDossier.getAvgXP()))
                    BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl'] = ((tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]) + 1
                    BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'] = tankman.descriptor.lastSkillNumber if not tankman.hasNewSkill else tankman.descriptor.lastSkillNumber+tankman.newSkillCount[0]
                    BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel'] = (tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]
                    BigWorld.crew_extended_data[tankman.invID]['freeXP'] = (tankman.descriptor.freeXP,millifyAvgXP(tankman.descriptor.freeXP))
                    BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'] = (getNextLevelXpCost(tankman),millifyAvgXP(getNextLevelXpCost(tankman)))
                    BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'] = (getLastLevelXpCost(tankman),millifyAvgXP(getLastLevelXpCost(tankman)))
                    BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'] = (getNextSkillBattlesLeft(extDossier, tankman),millifyAvgXP(getNextSkillBattlesLeft(extDossier, tankman)))
                    BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'] = (getLastSkillBattlesLeft(extDossier, tankman),millifyAvgXP(getLastSkillBattlesLeft(extDossier, tankman)))
                    tmp1,tmp2 = __checkSilverLearn(tankman)
                    BigWorld.crew_extended_data[tankman.invID]['SilverLearn'] = (tmp1,tmp2,millifyAvgXP(tmp2))
                # int
                format_int = {
                'training-level' : tankman.realRoleLevel[0],
                'exp-step-battles' : BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0] if BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0] > 0 else '1',
                'exp-total' : BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'][0],
                'training-battles' : BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0] if BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0] > 0 else '1',
                'nxtskillvlv' : BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl'],
                'skillsCnt' : BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'],
                'training-progress' : BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel'],
                'CurExp' : BigWorld.crew_extended_data[tankman.invID]['totalXP'][0],
                'exp-step' : BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'][0],
                'exp-extra-level' : BigWorld.crew_extended_data[tankman.invID]['SilverLearn'][1],
                'exp-free' : BigWorld.crew_extended_data[tankman.invID]['freeXP'][0],
                'lastSkillLevel': tankman.descriptor.lastSkillLevel
                }
                # string
                format_str = {
                'training-level' : str(tankman.realRoleLevel[0]),
                'firstname' : str(tankman.firstUserName),
                'lastname' : str(tankman.lastUserName),
                'rank' : str(tankman.rankUserName),
                'exp-total' : str(BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'][1]),
                'training-battles' : str(BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][1]) if BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0] > 0 else 'X',
                'nxtskillvlv' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl']),
                'skillsCnt' : str(BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber']),
                'training-progress' : str(BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel']),
                'role' : str(tankman.roleUserName),
                'CurExp' : str(BigWorld.crew_extended_data[tankman.invID]['totalXP'][1]),
                'vehicleType' : str(tankmanVehicle.shortUserName),
                'exp-step' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'][1]),
                'exp-step-battles' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][1]) if BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0] > 0 else 'X',
                'exp-extra-level' : str(BigWorld.crew_extended_data[tankman.invID]['SilverLearn'][2]),
                'exp-free' : str(BigWorld.crew_extended_data[tankman.invID]['freeXP'][1]),
                'lastSkillLevel' : str(tankman.descriptor.lastSkillLevel),
                'training-level-int' : str(tankman.realRoleLevel[0]),
                'exp-total-int' : str(BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'][0]),
                'training-battles-int' : str(BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0]) if BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0] > 0 else 'X',
                'nxtskillvlv-int' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl']),
                'skillsCnt-int' : str(BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber']),
                'training-progress-int' : str(BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel']),
                'CurExp-int' : str(BigWorld.crew_extended_data[tankman.invID]['totalXP'][0]),
                'exp-step-int' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'][0]),
                'exp-step-battles-int' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0]) if BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0] > 0 else 'X',
                'exp-extra-level-int' : str(BigWorld.crew_extended_data[tankman.invID]['SilverLearn'][1]),
                'exp-free-int' : str(BigWorld.crew_extended_data[tankman.invID]['freeXP'][0]),
                'lastSkillLevel-int': str(tankman.descriptor.lastSkillLevel)
                }
            tankmanData = {
             'firstname': BigWorld.crew_extended_settings['txt_hangar_firstname'].format(**format_str) if BigWorld.crew_extended_settings['hangar_crew_info'] else tankman.firstUserName,# всплывающее поле имени танкиста, серый цвет#+ tankman.firstUserName,
             'lastname': BigWorld.crew_extended_settings['txt_hangar_lastname'].format(**format_str) if BigWorld.crew_extended_settings['hangar_crew_info'] else tankman.lastUserName, # Поле фамилии танкиста, серый цвет #txt_Ears_Txt2,
             'rank': BigWorld.crew_extended_settings['txt_hangar_rank'].format(**format_str) if BigWorld.crew_extended_settings['hangar_crew_info'] else tankman.rankUserName, # Поле звания танкиста, серый цвет #txt_Ears_Txt1.format(exp100=txt_Ears_exp, battles100=txt_Ears_battles, nxtskillvlv=str(nxtskillvlv), skillsCnt=str(skillsCnt), skillvlv=str(skillvlv), CurExp=str(millifyAvgXP(CurExp)), rank=tankman.rankUserName, lastname=tankman.lastUserName),
             'specializationLevel': BigWorld.crew_extended_settings['txt_hangar_specializationLevel'].format(**format_int) if BigWorld.crew_extended_settings['hangar_crew_info'] else tankman.realRoleLevel[0], # 7 цифр(int), текущий уровень умения с бонусами #+str(tankman.realRoleLevel[0]),
             'role': BigWorld.crew_extended_settings['txt_hangar_colored_role'].format(**format_str) if BigWorld.crew_extended_settings['hangar_crew_info'] else tankman.roleUserName, # Всплывающее поле должности танкиста золотой цвет #+ tankman.roleUserName,
             'vehicleType': BigWorld.crew_extended_settings['txt_hangar_colored_vehicletype'].format(**format_str) if BigWorld.crew_extended_settings['hangar_crew_info'] else tankmanVehicle.shortUserName, #+ ,
             'iconFile': tankman.icon, # фотография танкиста
             'rankIconFile': tankman.iconRank,
             'roleIconFile': Tankman.getRoleBigIconPath(tankman.descriptor.role),
             'contourIconFile': tankmanVehicle.iconContour,
             'tankmanID': tankman.invID,
             'nationID': tankman.nationID,
             'typeID': tankmanVehicle.innationID,
             'inTank': tankman.isInTank,
             'roleType': tankman.descriptor.role,
             'tankType': tankmanVehicle.type,
             'efficiencyLevel': tankman.efficiencyRoleLevel,
             'bonus': bonus_role_level,
             'lastSkillLevel': BigWorld.crew_extended_settings['txt_hangar_colored_lastskilllevel'].format(**format_int) if BigWorld.crew_extended_settings['hangar_crew_info'] else tankman.descriptor.lastSkillLevel, # поле вывода уровня уровня скилла, коричневый цвет
             'isLessMastered': vehicle.crewIndices.get(tankman.invID) == lessMastered and vehicle.isXPToTman,
             'compact': tankman.strCD,
             'availableSkillsCount': skills_count,
             'skills': skillsList}
            tankmenData.append(tankmanData)
        self.as_tankmenResponseS(roles, tankmenData)
    Waiting.hide('updateTankmen')
    if BigWorld.crew_extended_settings['debug']:
        hook_profiler(new_updateTankmenAvgXP,False)
    return

def millifyAvgXP(n):
    millnames = ['', 'k', 'm']
    if n ==0 or n is None:
        return 0
    n = float(n)
    millidx = max(0, min(len(millnames) - 1, int(floor(log10(abs(n)) / 3))))
    return '%.0f%s' % (n / 10 ** (3 * millidx), millnames[millidx])


from gui.Scaleform.daapi.view.lobby.barracks.Barracks import Barracks
from gui.shared.gui_items.Tankman import TankmenComparator

def NewUpdateTankmen(self, *args):
    if BigWorld.crew_extended_settings['debug']:
        hook_profiler(NewUpdateTankmen,True)
    tankmen = g_itemsCache.items.getTankmen().values()
    slots = g_itemsCache.items.stats.tankmenBerthsCount
    berths = g_itemsCache.items.stats.tankmenBerthsCount
    berthPrice = g_itemsCache.items.shop.getTankmanBerthPrice(berths)
    defaultBerthPrice = g_itemsCache.items.shop.defaults.getTankmanBerthPrice(berths)
    tankmenList = list()
    tankmenInBarracks = 0
    for tankman in sorted(tankmen, TankmenComparator(g_itemsCache.items.getVehicle)):
        if not tankman.isInTank:
            tankmenInBarracks += 1
        slot, vehicleID, vehicleInnationID, vehicle = (None, None, None, None)
        if tankman.isInTank:
            vehicle = g_itemsCache.items.getVehicle(tankman.vehicleInvID)
            vehicleID = vehicle.invID
            vehicleInnationID = vehicle.innationID
            if vehicle is None:
                LOG_ERROR('Cannot find vehicle for tankman: ', tankman, tankman.descriptor.role, tankman.vehicle.name, tankman.firstname, tankman.lastname)
                continue
            slot = tankman.vehicleSlotIdx
        if self.filter['nation'] != -1 and tankman.nationID != self.filter['nation'] or self.filter['role'] != 'None' and tankman.descriptor.role != self.filter['role'] or self.filter['tankType'] != 'None' and tankman.vehicleNativeType != self.filter['tankType'] or self.filter['location'] == 'tanks' and tankman.isInTank != True or self.filter['location'] == 'barracks' and tankman.isInTank == True or self.filter['nationID'] is not None and (self.filter['location'] != str(vehicleInnationID) or self.filter['nationID'] != str(tankman.nationID)):
            continue
        isLocked, msg = self.getTankmanLockMessage(vehicle) if tankman.isInTank else (False, '')
        tankmanVehicle = g_itemsCache.items.getItemByCD(tankman.vehicleNativeDescr.type.compactDescr)
        isInCurrentTank = tankmanVehicle.invID == g_currentVehicle.invID if tankman.isInTank and g_currentVehicle.isPresent() else False
        if BigWorld.crew_extended_settings['barracks_crew_info']:
            if tankman.invID not in BigWorld.crew_extended_data:
                extDossier = g_itemsCache.items.getTankmanDossier(tankman.invID)
                BigWorld.crew_extended_data[tankman.invID] = {}
                #BigWorld.crew_extended_data[tankman.invID]['tankman'] = tankman
                BigWorld.crew_extended_data[tankman.invID]['totalXP'] = (tankman.descriptor.totalXP(),millifyAvgXP(tankman.descriptor.totalXP()))
                BigWorld.crew_extended_data[tankman.invID]['BattlesCount'] = (extDossier.getBattlesCount(),millifyAvgXP(extDossier.getBattlesCount()))
                BigWorld.crew_extended_data[tankman.invID]['AvgXP'] = (extDossier.getAvgXP(),millifyAvgXP(extDossier.getAvgXP()))
                BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl'] = ((tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]) + 1
                BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'] = tankman.descriptor.lastSkillNumber if not tankman.hasNewSkill else tankman.descriptor.lastSkillNumber+tankman.newSkillCount[0]
                BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel'] = (tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]
                BigWorld.crew_extended_data[tankman.invID]['freeXP'] = (tankman.descriptor.freeXP,millifyAvgXP(tankman.descriptor.freeXP))
                BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'] = (getNextLevelXpCost(tankman),millifyAvgXP(getNextLevelXpCost(tankman)))
                BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'] = (getLastLevelXpCost(tankman),millifyAvgXP(getLastLevelXpCost(tankman)))
                BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'] = (getNextSkillBattlesLeft(extDossier, tankman),millifyAvgXP(getNextSkillBattlesLeft(extDossier, tankman)))
                BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'] = (getLastSkillBattlesLeft(extDossier, tankman),millifyAvgXP(getLastSkillBattlesLeft(extDossier, tankman)))
                tmp1,tmp2 = __checkSilverLearn(tankman)
                BigWorld.crew_extended_data[tankman.invID]['SilverLearn'] = (tmp1,tmp2,millifyAvgXP(tmp2))
                BigWorld.crew_extended_data[tankman.invID]['skillicons'] = (str(BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'])+' ' if not tankman.hasNewSkill else str(tankman.descriptor.lastSkillNumber)+'('+str(BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'])+') ') if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else ''
                for skill in tankman.skills:
                    BigWorld.crew_extended_data[tankman.invID]['skillicons'] += "<img src='img://gui/maps/icons/tankmen/skills/small/"+skill.icon+"' width='14' height='14' align='baseline' vspace='-3'>"
                if tankman.hasNewSkill:
                    BigWorld.crew_extended_data[tankman.invID]['skillicons'] += "<img src='img://gui/maps/icons/tankmen/skills/small/new_skill.png' width='14' height='14' align='baseline' vspace='-3'>"
            if tankman.descriptor.totalXP() > BigWorld.crew_extended_data[tankman.invID]['totalXP']:
                extDossier = g_itemsCache.items.getTankmanDossier(tankman.invID)
                print(str(tankman.invID)+' exp changed to '+str(tankman.descriptor.totalXP() - BigWorld.crew_extended_data[tankman.invID]['totalXP'][0]))
                BigWorld.crew_extended_data[tankman.invID]['totalXP'] = (tankman.descriptor.totalXP(),millifyAvgXP(tankman.descriptor.totalXP()))
                BigWorld.crew_extended_data[tankman.invID]['BattlesCount'] = (extDossier.getBattlesCount(),millifyAvgXP(extDossier.getBattlesCount()))
                BigWorld.crew_extended_data[tankman.invID]['AvgXP'] = (extDossier.getAvgXP(),millifyAvgXP(extDossier.getAvgXP()))
                BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl'] = ((tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]) + 1
                BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'] = tankman.descriptor.lastSkillNumber if not tankman.hasNewSkill else tankman.descriptor.lastSkillNumber+tankman.newSkillCount[0]
                BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel'] = (tankman.descriptor.lastSkillLevel if tankman.descriptor.roleLevel == MAX_SKILL_LEVEL else tankman.descriptor.roleLevel) if not tankman.hasNewSkill else tankman.newSkillCount[1]
                BigWorld.crew_extended_data[tankman.invID]['freeXP'] = (tankman.descriptor.freeXP,millifyAvgXP(tankman.descriptor.freeXP))
                BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'] = (getNextLevelXpCost(tankman),millifyAvgXP(getNextLevelXpCost(tankman)))
                BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'] = (getLastLevelXpCost(tankman),millifyAvgXP(getLastLevelXpCost(tankman)))
                BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'] = (getNextSkillBattlesLeft(extDossier, tankman),millifyAvgXP(getNextSkillBattlesLeft(extDossier, tankman)))
                BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'] = (getLastSkillBattlesLeft(extDossier, tankman),millifyAvgXP(getLastSkillBattlesLeft(extDossier, tankman)))
                tmp1,tmp2 = __checkSilverLearn(tankman)
                BigWorld.crew_extended_data[tankman.invID]['SilverLearn'] = (tmp1,tmp2,millifyAvgXP(tmp2))
                BigWorld.crew_extended_data[tankman.invID]['skillicons'] = ''
                for skill in tankman.skills:
                    BigWorld.crew_extended_data[tankman.invID]['skillicons'] += "<img src='img://gui/maps/icons/tankmen/skills/small/"+skill.icon+"' width='14' height='14' align='baseline' vspace='-3'>"
                if tankman.hasNewSkill:
                    BigWorld.crew_extended_data[tankman.invID]['skillicons'] += "<img src='img://gui/maps/icons/tankmen/skills/small/new_skill.png' width='14' height='14' align='baseline' vspace='-3'>"
                BigWorld.crew_extended_data[tankman.invID]['skillicons']
            if not hasattr(BigWorld.crew_extended_data[tankman.invID], 'skillicons'):
                BigWorld.crew_extended_data[tankman.invID]['skillicons'] = ''
                for skill in tankman.skills:
                    BigWorld.crew_extended_data[tankman.invID]['skillicons'] += "<img src='img://gui/maps/icons/tankmen/skills/small/"+skill.icon+"' width='14' height='14' align='baseline' vspace='-3'>"
                if tankman.hasNewSkill:
                    BigWorld.crew_extended_data[tankman.invID]['skillicons'] += "<img src='img://gui/maps/icons/tankmen/skills/small/new_skill.png' width='14' height='14' align='baseline' vspace='-3'>"
            # int
            format_int = {
            'training-level' : tankman.realRoleLevel[0],
            'exp-step-battles' : BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0] if BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0] > 0 else '1',
            'exp-total' : BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'][0],
            'training-battles' : BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0] if BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0] > 0 else '1',
            'nxtskillvlv' : BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl'],
            'skillsCnt' : BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber'],
            'training-progress' : BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel'],
            'CurExp' : BigWorld.crew_extended_data[tankman.invID]['totalXP'][0],
            'exp-step' : BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'][0],
            'exp-extra-level' : BigWorld.crew_extended_data[tankman.invID]['SilverLearn'][1],
            'exp-free' : BigWorld.crew_extended_data[tankman.invID]['freeXP'][0],
            'lastSkillLevel': tankman.descriptor.lastSkillLevel
            }
            # string
            format_str = {
            'training-level' : str(tankman.realRoleLevel[0]),
            'firstname' : str(tankman.firstUserName),
            'lastname' : str(tankman.lastUserName),
            'rank' : str(tankman.rankUserName),
            'exp-total' : str(BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'][1]),
            'training-battles' : str(BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][1]) if BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0] > 0 else 'X',
            'nxtskillvlv' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl']),
            'skillsCnt' : str(BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber']),
            'training-progress' : str(BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel']),
            'role' : str(tankman.roleUserName),
            'CurExp' : str(BigWorld.crew_extended_data[tankman.invID]['totalXP'][1]),
            'vehicleType' : str(tankmanVehicle.shortUserName),
            'exp-step' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'][1]),
            'exp-step-battles' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][1]) if BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0] > 0 else 'X',
            'exp-extra-level' : str(BigWorld.crew_extended_data[tankman.invID]['SilverLearn'][2]),
            'exp-free' : str(BigWorld.crew_extended_data[tankman.invID]['freeXP'][1]),
            'lastSkillLevel' : str(tankman.descriptor.lastSkillLevel),
            'training-level-int' : str(tankman.realRoleLevel[0]),
            'exp-total-int' : str(BigWorld.crew_extended_data[tankman.invID]['LastLevelXpCost'][0]),
            'training-battles-int' : str(BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0]) if BigWorld.crew_extended_data[tankman.invID]['LastSkillBattlesLeft'][0] > 0 else 'X',
            'nxtskillvlv-int' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillLvl']),
            'skillsCnt-int' : str(BigWorld.crew_extended_data[tankman.invID]['lastSkillNumber']),
            'training-progress-int' : str(BigWorld.crew_extended_data[tankman.invID]['lastSkillLevel']),
            'CurExp-int' : str(BigWorld.crew_extended_data[tankman.invID]['totalXP'][0]),
            'exp-step-int' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillXPLeft'][0]),
            'exp-step-battles-int' : str(BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0]) if BigWorld.crew_extended_data[tankman.invID]['nextSkillBattlesLeft'][0] > 0 else 'X',
            'exp-extra-level-int' : str(BigWorld.crew_extended_data[tankman.invID]['SilverLearn'][1]),
            'exp-free-int' : str(BigWorld.crew_extended_data[tankman.invID]['freeXP'][0]),
            'skillicons': str(BigWorld.crew_extended_data[tankman.invID]['skillicons']),
            'lockMessage': str(msg),
            'lastSkillLevel-int': str(tankman.descriptor.lastSkillLevel)
            }
        tankmenList.append({'firstname': BigWorld.crew_extended_settings['txt_barracks_firstname'].format(**format_str) if BigWorld.crew_extended_settings['barracks_crew_info'] else tankman.firstUserName, #text
         'lastname': BigWorld.crew_extended_settings['txt_barracks_lastname'].format(**format_str) if BigWorld.crew_extended_settings['barracks_crew_info'] else tankman.lastUserName, #text
         'rank': BigWorld.crew_extended_settings['txt_barracks_rank'].format(**format_str) if BigWorld.crew_extended_settings['barracks_crew_info'] else tankman.rankUserName, #text
         'specializationLevel': tankman.realRoleLevel[0],
         'role': BigWorld.crew_extended_settings['txt_barracks_colored_role'].format(**format_str) if BigWorld.crew_extended_settings['barracks_crew_info'] else tankman.roleUserName, #html
         'vehicleType': BigWorld.crew_extended_settings['txt_barracks_colored_vehicleType'].format(**format_str) if BigWorld.crew_extended_settings['barracks_crew_info'] else tankmanVehicle.shortUserName, #html
         'iconFile': tankman.icon,
         'rankIconFile': tankman.iconRank,
         'roleIconFile': Tankman.getRoleBigIconPath(tankman.descriptor.role),
         'contourIconFile': tankmanVehicle.iconContour,
         'tankmanID': tankman.invID,
         'nationID': tankman.nationID,
         'typeID': tankmanVehicle.innationID,
         'slot': slot,
         'roleType': tankman.descriptor.role,#?
         'tankType': (tankmanVehicle.type), #html
         'inTank': tankman.isInTank,
         'inCurrentTank': isInCurrentTank,
         'vehicleID': vehicleID,
         'compact': str(tankman.invID),
         'locked': isLocked,
         'lockMessage': BigWorld.crew_extended_settings['txt_barracks_lockMessage'].format(**format_str) if BigWorld.crew_extended_settings['barracks_crew_info'] else msg, #text
         'vehicleBroken': vehicle.repairCost > 0 if tankman.isInTank else None,
         'isInSelfVehicleClass': vehicle.type == tankmanVehicle.type if tankman.isInTank else True,
         'isInSelfVehicleType': vehicle.shortUserName == tankmanVehicle.shortUserName if tankman.isInTank else True})

    action = None
    if berthPrice[0] != defaultBerthPrice[0]:
        action = {'type': ACTION_TOOLTIPS_TYPE.ECONOMICS,
         'key': 'berthsPrices',
         'isBuying': True,
         'state': (None, ACTION_TOOLTIPS_STATE.DISCOUNT),
         'newPrice': (0, berthPrice[0]),
         'oldPrice': (0, defaultBerthPrice[0])}
    self.as_setTankmenS(len(tankmen), slots, tankmenInBarracks, BigWorld.wg_getGoldFormat(berthPrice[0]), action, berthPrice[1], tankmenList)
    if BigWorld.crew_extended_settings['debug']:
        hook_profiler(NewUpdateTankmen,False)
    return

Barracks._Barracks__updateTankmen = NewUpdateTankmen

Init()

    
