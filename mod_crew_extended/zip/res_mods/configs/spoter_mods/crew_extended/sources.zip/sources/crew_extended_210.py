﻿# -*- coding: utf-8 -*- 
import BigWorld
import ResMgr
from gui.shared.gui_items.dossier import TankmanDossier
from helpers.i18n import makeString
from items.tankmen import MAX_SKILL_LEVEL
from math import ceil, floor, log10
from helpers.i18n import convert
from gui.Scaleform.Waiting import Waiting
from CurrentVehicle import g_currentVehicle
from gui.shared import events, g_itemsCache
from gui.Scaleform.daapi.view.lobby.hangar.Crew import Crew
from items.tankmen import getSkillsConfig, compareMastery, ACTIVE_SKILLS
getStatsCrewselSelfId = None

txt_premium_bonus_on = 'Premium bonus for exp: Enabled'
txt_premium_bonus_off = 'Premium bonus for exp: Disabled'
txt_up_to_exp = 'Experience to'
txt_up_to_btl = 'Battles to'
txt_skill_number = 'Skill'
txt_basic_skill = 'Basic skill'
txt_SilverReLearn = 'Retraining'
txt_SilverReLearn_need = 'for credits need'
txt_SilverReLearn_ready = 'for credits ready!'
#Видимо постоянно
txt_Ears_specializationLevel = '{training-level}'
txt_Ears_rank = '{rank}'
txt_Ears_lastname = '{lastname}'
txt_Ears_colored_lastSkillLevel = '{lastSkillLevel}'
#Всплывающее
txt_Ears_firstname = '{firstname}'
txt_Ears_colored_role = '[<font color="#00FF00">{training-battles}</font>\<font color="#FFFF00">{exp-total}</font>]{role}'
txt_Ears_colored_vehicleType = '{vehicleType}'

XMLFILE = ResMgr.openSection('scripts/client/mods/crew_extended.xml')


description = 'ExtendedCrew'
version = 'v2.10 (10/02/2015)'
author = 'by spoter'



OTHERLANG = XMLFILE['OtherLanguage']
EARS = XMLFILE['Ears']
CFG = {}


print ''
print '[LOAD_MOD]:  ['+str(description)+' '+str(author)+']'
print '[INFO]:      ['+str(description)+' '+str(version)+' initialized ...]'
CFG['ext_crew_language'] = XMLFILE.readString('Language')
if True:
    if CFG['ext_crew_language'] == 'Ru':
        print '[INFO]:      [ExtendedCrew Language set to : "RUSSIAN"...]'
    elif CFG['ext_crew_language'] == 'En':
        print '[INFO]:      [ExtendedCrew Language set to : "ENGLISH"...]'
    elif CFG['ext_crew_language'] == 'De':
        print '[INFO]:      [ExtendedCrew Language set to : "GERMAN"...]'
    elif CFG['ext_crew_language'] == 'Other':
        print '[INFO]:      [ExtendedCrew Language set to : "OTHER". Uses custom strings from XML file in section "OtherLanguage"...]'
    else:
        print '[WARNING]:      [ExtendedCrew XML Error ! Language set to : ENGLISH]'



def conf_loads():
    global getStatsCrewselSelfId
    self = getStatsCrewselSelfId
    if EARS is not None:
        txt_Ears_specializationLevel = EARS.readString('specializationLevel')
        txt_Ears_rank =  EARS.readString('rank')
        txt_Ears_lastname =  EARS.readString('lastname')
        txt_Ears_colored_lastSkillLevel =  EARS.readString('colored_lastSkillLevel')
        txt_Ears_firstname =  EARS.readString('firstname')
        txt_Ears_colored_role =  EARS.readString('colored_role')
        txt_Ears_colored_vehicleType =  EARS.readString('colored_vehicleType')
                
    else:
        txt_Ears_specializationLevel = '{training-level}'
        txt_Ears_rank = '{rank}'
        txt_Ears_lastname = '{lastname}'
        txt_Ears_colored_lastSkillLevel = '{lastSkillLevel}'
        txt_Ears_firstname = '{firstname}'
        txt_Ears_colored_role = '[<font color="#00FF00">{training-battles}</font>\<font color="#FFFF00">{exp-total}</font>]{role}'
        txt_Ears_colored_vehicleType = '{vehicleType}'
    
    txt_up_to_exp = txt_up_to_btl = txt_skill_number = txt_basic_skill = txt_SilverReLearn = txt_SilverReLearn_need = txt_SilverReLearn_ready = '' 
    CFG['ext_crew_language'] = XMLFILE.readString('Language')
    if CFG['ext_crew_language'] is not None:
        if CFG['ext_crew_language'] == 'Ru':
            #print '[INFO]: ExtendedCrew Language set to : "RUSSIAN"...'
            txt_premium_bonus_on = 'Премиум бонус на опыт: Активирован'
            txt_premium_bonus_off = 'Премиум бонус на опыт: Неактивен'
            txt_up_to_exp = 'Опыта до'
            txt_up_to_btl = 'Боёв до'
            txt_skill_number = 'Навык'
            txt_basic_skill = 'Базовый навык'
            txt_SilverReLearn = 'Переобучение'
            txt_SilverReLearn_need = 'за кредиты надо'
            txt_SilverReLearn_ready = 'за кредиты Готово!'
        elif CFG['ext_crew_language'] == 'En':
            #print '[INFO]: ExtendedCrew Language set to : "ENGLISH"...'
            txt_premium_bonus_on = 'Premium bonus for exp: Enabled'
            txt_premium_bonus_off = 'Premium bonus for exp: Disabled'
            txt_up_to_exp = 'Experience to'
            txt_up_to_btl = 'Battles to'
            txt_skill_number = 'Skill'
            txt_basic_skill = 'Basic skill'
            txt_SilverReLearn = 'Retraining'
            txt_SilverReLearn_need = 'for credits need'
            txt_SilverReLearn_ready = 'for credits ready!'
        elif CFG['ext_crew_language'] == 'De':
            #print '[INFO]: ExtendedCrew Language set to : "GERMAN"...'
            txt_premium_bonus_on = 'Erfahrungsbonus: Enabled'
            txt_premium_bonus_off = 'Erfahrungsbonus: Disabled'
            txt_up_to_exp = 'Erfahrung bis'
            txt_up_to_btl = 'Kampfe bis'
            txt_skill_number = 'Fertigkeit'
            txt_basic_skill = 'Grundperk'
            txt_SilverReLearn = 'Umschulung'
            txt_SilverReLearn_need = 'fuer Kredits ben. '
            txt_SilverReLearn_ready = 'fuer Kredits bereit!'
        elif CFG['ext_crew_language'] == 'Other':
            #print '[INFO]: ExtendedCrew Language set to : "OTHER". Uses custom strings from XML file in section "OtherLanguage"...'
            Custom_string_premium_bonus_on = OTHERLANG.readString('Custom_string_premium_bonus_on')
            Custom_string_premium_bonus_off = OTHERLANG.readString('Custom_string_premium_bonus_off')
            Custom_string_up_to_exp = OTHERLANG.readString('Custom_string_up_to_exp')
            Custom_string_up_to_btl = OTHERLANG.readString('Custom_string_up_to_btl')
            Custom_skill_number = OTHERLANG.readString('Custom_skill_number')
            Custom_basic_skill = OTHERLANG.readString('Custom_basic_skill')
            Custom_SilverReLearn = OTHERLANG.readString('Custom_SilverReLearn')
            Custom_SilverReLearn_need = OTHERLANG.readString('Custom_SilverReLearn_need')
            Custom_SilverReLearn_ready = OTHERLANG.readString('Custom_SilverReLearn_ready')
            txt_premium_bonus_on = Custom_string_premium_bonus_on
            txt_premium_bonus_off = Custom_string_premium_bonus_off
            txt_up_to_exp = Custom_string_up_to_exp
            txt_up_to_btl = Custom_string_up_to_btl
            txt_skill_number = Custom_skill_number
            txt_basic_skill = Custom_basic_skill
            txt_SilverReLearn = Custom_SilverReLearn
            txt_SilverReLearn_need = Custom_SilverReLearn_need
            txt_SilverReLearn_ready = Custom_SilverReLearn_ready
    else:
        print '[WARNING]: ExtendedCrew XML Error ! Language set to : ENGLISH'
    return (txt_premium_bonus_on, txt_premium_bonus_off,txt_up_to_exp, txt_up_to_btl, txt_skill_number, txt_basic_skill, txt_SilverReLearn, txt_SilverReLearn_need,txt_SilverReLearn_ready,txt_Ears_specializationLevel,txt_Ears_rank,txt_Ears_lastname,txt_Ears_firstname,txt_Ears_colored_role,txt_Ears_colored_vehicleType,txt_Ears_colored_lastSkillLevel)




def new_getStatsCrew095(self):
    global getStatsCrewselSelfId
    tmanDescr = self.tmanDescr
    txt_premium_bonus_on, txt_premium_bonus_off, txt_up_to_exp, txt_up_to_btl, txt_skill_number, txt_basic_skill, txt_SilverReLearn, txt_SilverReLearn_need,txt_SilverReLearn_ready,txt_Ears_specializationLevel,txt_Ears_rank,txt_Ears_lastname,txt_Ears_firstname, txt_Ears_colored_role,txt_Ears_colored_vehicleType,txt_Ears_colored_lastSkillLevel = conf_loads()
    getStatsCrewselSelfId = self
    nextSkillsBattlesLeft = self._TankmanDossier__getNextSkillBattlesLeft()
    nextSkillBattlesLeftExtra = ''
    if nextSkillsBattlesLeft is not None:
        nextSkillsBattlesLeft = nextSkillsBattlesLeft
    else:
        nextSkillBattlesLeftExtra = '(%s)' % makeString('#menu:profile/stats/items/unknown')
    skillImgType, skillImg = self._TankmanDossier__getCurrentSkillIcon()
    imageType, image = self._TankmanDossier__getCurrentSkillIcon()
    skillsCnt, skillvlv, CurExp = lastLvlInfo(tmanDescr)
    lastSkillLevel = self.tmanDescr.lastSkillLevel
    if self.tmanDescr.roleLevel != MAX_SKILL_LEVEL:
        lastSkillLevel = self.tmanDescr.roleLevel
    arg1_xp = ''
    arg2_xp = getCurExpCrew(tmanDescr)
    if self.tmanDescr.roleLevel == MAX_SKILL_LEVEL:
        getTxtReady = str(len(self.tmanDescr.skills)) + '. ' + txt_skill_number
        arg1_nextSkillXPLeft1 = txt_up_to_exp + ' ' + str(skillvlv + 1) + '%'
        getNextSkillXPLeft = getExpLevelGenerator(tmanDescr, setSkillLvl=skillvlv, setSkillsCount=skillsCnt)
        freeXp = self.tmanDescr.freeXP
        if freeXp < getNextSkillXPLeft:
            getNextSkillXPLeft = getNextSkillXPLeft - freeXp
        arg2_nextSkillXPLeft1_temp = getNextSkillXPLeft
        arg1_nextSkillBattlesLeft1 = txt_up_to_btl + ' ' + str(skillvlv + 1) + '%'
        avgExp = self.getAvgXP()
        if avgExp:
            getNextSkillBattlesLefts = max(1, ceil(getNextSkillXPLeft / avgExp))
        else:
            getNextSkillBattlesLefts = None
        arg2_nextSkillBattlesLeft1_temp = getNextSkillBattlesLefts
    else:
        getTxtReady = txt_basic_skill
        arg1_nextSkillXPLeft1 = txt_up_to_exp + ' ' + str(lastSkillLevel + 1) + '%'
        arg2_nextSkillXPLeft1_temp = self._TankmanDossier__getNextSkillXPLeft()
        arg1_nextSkillBattlesLeft1 = txt_up_to_btl + ' ' + str(lastSkillLevel + 1) + '%'
        arg2_nextSkillBattlesLeft1_temp = nextSkillsBattlesLeft

    nextSkillXPLeft2 = getNextExpCrew(tmanDescr)
    nextSkillBattlesLeft2 = getNextBattleCrew()
    arg2_nextSkillXPLeft1_temp
    arg2_nextSkillBattlesLeft1_temp
    xpFactorToUse = 1.0
    #xpFactorToUse = self.PREMIUM_TANK_DEFAULT_CREW_XP_FACTOR
    if self._TankmanDossier__currentVehicleIsPremium:
        xpFactorToUse = self._TankmanDossier__currentVehicleCrewXpFactor
    if nextSkillBattlesLeft2 is not None and nextSkillBattlesLeft2 !=0:
        nextSkillBattlesLeft2 = max(1, nextSkillBattlesLeft2 / xpFactorToUse)
    else:
        nextSkillBattlesLeft2 = 0

    if arg2_nextSkillBattlesLeft1_temp is not None and arg2_nextSkillBattlesLeft1_temp !=0:
        arg2_nextSkillBattlesLeft1_temp = max(1, arg2_nextSkillBattlesLeft1_temp / xpFactorToUse)
    else:
        arg2_nextSkillBattlesLeft1_temp = 0


    arg2_nextSkillXPLeft1 = BigWorld.wg_getIntegralFormat(arg2_nextSkillXPLeft1_temp)
    arg2_nextSkillBattlesLeft1 = BigWorld.wg_getIntegralFormat(arg2_nextSkillBattlesLeft1_temp) if arg2_nextSkillBattlesLeft1_temp else '(%s)' % makeString('#menu:profile/stats/items/unknown')

    arg1_nextSkillXPLeft2 = txt_up_to_exp + ' 100%'
    arg2_nextSkillXPLeft2 = BigWorld.wg_getIntegralFormat(nextSkillXPLeft2)

    arg1_nextSkillBattlesLeft2 = txt_up_to_btl + ' 100%'
    arg2_nextSkillBattlesLeft2 = BigWorld.wg_getIntegralFormat(nextSkillBattlesLeft2) if nextSkillBattlesLeft2 else '(%s)' % makeString('#menu:profile/stats/items/unknown')


    SilverLearn = checkSilverLearn(tmanDescr)
    if SilverLearn == 'Ready':
        arg1_SilverLearn = txt_SilverReLearn
        arg2_SilverLearn = txt_SilverReLearn_ready
    else:
        arg1_SilverLearn = txt_SilverReLearn
        arg2_SilverLearn = txt_SilverReLearn_need + ' ' + str(SilverLearn) + '%'
    from helpers import i18n
    from gui.Scaleform.locale.MENU import MENU
    if SilverLearn == None:
        return ({'stats': (
        {'name': 'battlesCount', 'value': BigWorld.wg_getIntegralFormat(self.getBattlesCount()), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'avgExperience', 'value': BigWorld.wg_getIntegralFormat(self.getAvgXP()), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'xp', 'value':  str(BigWorld.wg_getIntegralFormat(arg2_xp)), 'premiumValue': '', 'imageType': skillImgType, 'image': skillImg},
        {'name': 'ready', 'value': getTxtReady, 'premiumValue': '', 'imageType': None, 'image': None}
        ), 'label': 'common'}, {'isPremium': True, 'stats': (
        {'name': 'empty', 'value': str(arg2_nextSkillXPLeft2) + ' ' + str(arg1_nextSkillXPLeft2), 'premiumValue': str(arg2_nextSkillXPLeft1)+' '+ str(arg1_nextSkillXPLeft1), 'imageType': None, 'image': None},
        {'name': 'empty', 'value': str(arg2_nextSkillBattlesLeft2) + ' ' + str(arg1_nextSkillBattlesLeft2), 'premiumValue': str(arg2_nextSkillBattlesLeft1) + ' ' + str(arg1_nextSkillBattlesLeft1), 'imageType': None, 'image': None}
        ), 'secondLabel': '['+description+' '+version+'] '+txt_premium_bonus_on +' (x'+str(xpFactorToUse)+')' if self._TankmanDossier__currentVehicleIsPremium else '['+description+' '+version+'] '+txt_premium_bonus_off, 'label': 'studying'
        }
        )
    else:
        return ({'stats': (
        {'name': 'battlesCount', 'value': BigWorld.wg_getIntegralFormat(self.getBattlesCount()), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'avgExperience', 'value': BigWorld.wg_getIntegralFormat(self.getAvgXP()), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'xp', 'value':  str(BigWorld.wg_getIntegralFormat(arg2_xp)), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'ready', 'value': getTxtReady, 'premiumValue': '', 'imageType': None, 'image': None}
        ), 'label': 'common'}, {'isPremium': True, 'stats': (
        {'name': 'empty', 'value': str(arg2_nextSkillXPLeft2) + ' ' + str(arg1_nextSkillXPLeft2), 'premiumValue': str(arg2_nextSkillXPLeft1)+' '+ str(arg1_nextSkillXPLeft1), 'imageType': None, 'image': None},
        {'name': 'empty', 'value': str(arg2_nextSkillBattlesLeft2) + ' ' + str(arg1_nextSkillBattlesLeft2), 'premiumValue': str(arg2_nextSkillBattlesLeft1) + ' ' + str(arg1_nextSkillBattlesLeft1), 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'ready', 'value': '', 'premiumValue': '', 'imageType': skillImgType, 'image': skillImg},
        {'name': 'empty', 'value': arg1_SilverLearn, 'premiumValue': arg2_SilverLearn, 'imageType': None, 'image': None}
        ), 'secondLabel': '['+description+' '+version+'] '+txt_premium_bonus_on +' (x'+str(xpFactorToUse)+')' if self._TankmanDossier__currentVehicleIsPremium else '['+description+' '+version+'] '+txt_premium_bonus_off, 'label': 'studying'
        }
        )
    return None




def new_getStatsCrew(self,tankman):
    global getStatsCrewselSelfId
    tmanDescr = self.tmanDescr
    txt_premium_bonus_on, txt_premium_bonus_off, txt_up_to_exp, txt_up_to_btl, txt_skill_number, txt_basic_skill, txt_SilverReLearn, txt_SilverReLearn_need,txt_SilverReLearn_ready,txt_Ears_specializationLevel,txt_Ears_rank,txt_Ears_lastname,txt_Ears_firstname, txt_Ears_colored_role,txt_Ears_colored_vehicleType,txt_Ears_colored_lastSkillLevel = conf_loads()
    getStatsCrewselSelfId = self
    nextSkillsBattlesLeft = self._TankmanDossier__getNextSkillBattlesLeft(tankman)
    nextSkillBattlesLeftExtra = ''
    if nextSkillsBattlesLeft is not None:
        nextSkillsBattlesLeft = nextSkillsBattlesLeft
    else:
        nextSkillBattlesLeftExtra = '(%s)' % makeString('#menu:profile/stats/items/unknown')
    skillImgType, skillImg = self._TankmanDossier__getCurrentSkillIcon()
    imageType, image = self._TankmanDossier__getCurrentSkillIcon()
    skillsCnt, skillvlv, CurExp = lastLvlInfo(tmanDescr)
    lastSkillLevel = self.tmanDescr.lastSkillLevel
    if self.tmanDescr.roleLevel != MAX_SKILL_LEVEL:
        lastSkillLevel = self.tmanDescr.roleLevel
    arg1_xp = ''
    arg2_xp = getCurExpCrew(tmanDescr)
    if self.tmanDescr.roleLevel == MAX_SKILL_LEVEL:
        getTxtReady = str(len(self.tmanDescr.skills)) + '. ' + txt_skill_number
        arg1_nextSkillXPLeft1 = txt_up_to_exp + ' ' + str(skillvlv + 1) + '%'
        getNextSkillXPLeft = getExpLevelGenerator(tmanDescr, setSkillLvl=skillvlv, setSkillsCount=skillsCnt)
        freeXp = self.tmanDescr.freeXP
        if freeXp < getNextSkillXPLeft:
            getNextSkillXPLeft = getNextSkillXPLeft - freeXp
        arg2_nextSkillXPLeft1_temp = getNextSkillXPLeft
        arg1_nextSkillBattlesLeft1 = txt_up_to_btl + ' ' + str(skillvlv + 1) + '%'
        avgExp = self.getAvgXP()
        if avgExp:
            getNextSkillBattlesLefts = max(1, ceil(getNextSkillXPLeft / avgExp))
        else:
            getNextSkillBattlesLefts = None
        arg2_nextSkillBattlesLeft1_temp = getNextSkillBattlesLefts
    else:
        getTxtReady = txt_basic_skill
        arg1_nextSkillXPLeft1 = txt_up_to_exp + ' ' + str(lastSkillLevel + 1) + '%'
        arg2_nextSkillXPLeft1_temp = self._TankmanDossier__getNextSkillXPLeft()
        arg1_nextSkillBattlesLeft1 = txt_up_to_btl + ' ' + str(lastSkillLevel + 1) + '%'
        arg2_nextSkillBattlesLeft1_temp = nextSkillsBattlesLeft
    
    nextSkillXPLeft2 = getNextExpCrew(tmanDescr)
    nextSkillBattlesLeft2 = getNextBattleCrew()
    arg2_nextSkillXPLeft1_temp
    arg2_nextSkillBattlesLeft1_temp
    xpFactorToUse = 1.0
    #xpFactorToUse = self.PREMIUM_TANK_DEFAULT_CREW_XP_FACTOR
    if self._TankmanDossier__currentVehicleIsPremium:
        xpFactorToUse = self._TankmanDossier__currentVehicleCrewXpFactor
    if nextSkillBattlesLeft2 is not None and nextSkillBattlesLeft2 !=0:
        nextSkillBattlesLeft2 = max(1, nextSkillBattlesLeft2 / xpFactorToUse)
    else:
        nextSkillBattlesLeft2 = 0
        
    if arg2_nextSkillBattlesLeft1_temp is not None and arg2_nextSkillBattlesLeft1_temp !=0:
        arg2_nextSkillBattlesLeft1_temp = max(1, arg2_nextSkillBattlesLeft1_temp / xpFactorToUse)
    else:
        arg2_nextSkillBattlesLeft1_temp = 0

    
    arg2_nextSkillXPLeft1 = BigWorld.wg_getIntegralFormat(arg2_nextSkillXPLeft1_temp)
    arg2_nextSkillBattlesLeft1 = BigWorld.wg_getIntegralFormat(arg2_nextSkillBattlesLeft1_temp) if arg2_nextSkillBattlesLeft1_temp else '(%s)' % makeString('#menu:profile/stats/items/unknown')
    
    arg1_nextSkillXPLeft2 = txt_up_to_exp + ' 100%'
    arg2_nextSkillXPLeft2 = BigWorld.wg_getIntegralFormat(nextSkillXPLeft2)
    
    arg1_nextSkillBattlesLeft2 = txt_up_to_btl + ' 100%'
    arg2_nextSkillBattlesLeft2 = BigWorld.wg_getIntegralFormat(nextSkillBattlesLeft2) if nextSkillBattlesLeft2 else '(%s)' % makeString('#menu:profile/stats/items/unknown')
    
    
    SilverLearn = checkSilverLearn(tmanDescr)
    if SilverLearn == 'Ready':
        arg1_SilverLearn = txt_SilverReLearn
        arg2_SilverLearn = txt_SilverReLearn_ready
    else:
        arg1_SilverLearn = txt_SilverReLearn
        arg2_SilverLearn = txt_SilverReLearn_need + ' ' + str(SilverLearn) + '%'
    from helpers import i18n
    from gui.Scaleform.locale.MENU import MENU
    if SilverLearn == None:
        return ({'stats': (
        {'name': 'battlesCount', 'value': BigWorld.wg_getIntegralFormat(self.getBattlesCount()), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'avgExperience', 'value': BigWorld.wg_getIntegralFormat(self.getAvgXP()), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'xp', 'value':  str(BigWorld.wg_getIntegralFormat(arg2_xp)), 'premiumValue': '', 'imageType': skillImgType, 'image': skillImg},
        {'name': 'ready', 'value': getTxtReady, 'premiumValue': '', 'imageType': None, 'image': None}
        ), 'label': 'common'}, {'isPremium': True, 'stats': (
        {'name': 'empty', 'value': str(arg2_nextSkillXPLeft2) + ' ' + str(arg1_nextSkillXPLeft2), 'premiumValue': str(arg2_nextSkillXPLeft1)+' '+ str(arg1_nextSkillXPLeft1), 'imageType': None, 'image': None},
        {'name': 'empty', 'value': str(arg2_nextSkillBattlesLeft2) + ' ' + str(arg1_nextSkillBattlesLeft2), 'premiumValue': str(arg2_nextSkillBattlesLeft1) + ' ' + str(arg1_nextSkillBattlesLeft1), 'imageType': None, 'image': None}
        ), 'secondLabel': '['+description+' '+version+'] '+txt_premium_bonus_on +' (x'+str(xpFactorToUse)+')' if self._TankmanDossier__currentVehicleIsPremium else '['+description+' '+version+'] '+txt_premium_bonus_off, 'label': 'studying'
        }
        )
    else:
        return ({'stats': (
        {'name': 'battlesCount', 'value': BigWorld.wg_getIntegralFormat(self.getBattlesCount()), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'avgExperience', 'value': BigWorld.wg_getIntegralFormat(self.getAvgXP()), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'xp', 'value':  str(BigWorld.wg_getIntegralFormat(arg2_xp)), 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'ready', 'value': getTxtReady, 'premiumValue': '', 'imageType': None, 'image': None}
        ), 'label': 'common'}, {'isPremium': True, 'stats': (
        {'name': 'empty', 'value': str(arg2_nextSkillXPLeft2) + ' ' + str(arg1_nextSkillXPLeft2), 'premiumValue': str(arg2_nextSkillXPLeft1)+' '+ str(arg1_nextSkillXPLeft1), 'imageType': None, 'image': None},
        {'name': 'empty', 'value': str(arg2_nextSkillBattlesLeft2) + ' ' + str(arg1_nextSkillBattlesLeft2), 'premiumValue': str(arg2_nextSkillBattlesLeft1) + ' ' + str(arg1_nextSkillBattlesLeft1), 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'empty', 'value': '', 'premiumValue': '', 'imageType': None, 'image': None},
        {'name': 'ready', 'value': '', 'premiumValue': '', 'imageType': skillImgType, 'image': skillImg},
        {'name': 'empty', 'value': arg1_SilverLearn, 'premiumValue': arg2_SilverLearn, 'imageType': None, 'image': None}
        ), 'secondLabel': '['+description+' '+version+'] '+txt_premium_bonus_on +' (x'+str(xpFactorToUse)+')' if self._TankmanDossier__currentVehicleIsPremium else '['+description+' '+version+'] '+txt_premium_bonus_off, 'label': 'studying'
        }
        )
    return None


if BigWorld.wg_getProductVersion() == '0, 9, 5, 0':
    TankmanDossier.getStats = new_getStatsCrew095
if BigWorld.wg_getProductVersion() != '0, 9, 5, 0':
    TankmanDossier.getStats = new_getStatsCrew




def getExpLevelGenerator(tmanDescr, setSkillsCount, setSkillLvl):
    return tmanDescr.levelUpXpCost(setSkillLvl, setSkillsCount)


def table(skillsCount):
    readyFlag = 0
    CurExp = 0
    skillsCnt = 0
    if skillsCount == 0 and readyFlag == 0:
        CurExp = 95484
        readyFlag = 1
        skillsCnt = 1
    if skillsCount == 1 and readyFlag == 0:
        CurExp = 305544
        readyFlag = 1
        skillsCnt = 2
    if skillsCount == 2 and readyFlag == 0:
        CurExp = 725664
        readyFlag = 1
        skillsCnt = 3
    if skillsCount == 3 and readyFlag == 0:
        CurExp = 1565904
        readyFlag = 1
        skillsCnt = 4
    if skillsCount == 4 and readyFlag == 0:
        CurExp = 3246384
        readyFlag = 1
        skillsCnt = 5
    if skillsCount == 5 and readyFlag == 0:
        CurExp = 6607344
        readyFlag = 1
        skillsCnt = 6
    if skillsCount == 6 and readyFlag == 0:
        CurExp = 13329264
        readyFlag = 1
        skillsCnt = 7
    if skillsCount == 7 and readyFlag == 0:
        CurExp = 26773104
        readyFlag = 1
        skillsCnt = 8
    if skillsCount == 8 and readyFlag == 0:
        CurExp = 53660784
        readyFlag = 1
        skillsCnt = 9
    if skillsCount == 9 and readyFlag == 0:
        CurExp = 107436144
        readyFlag = 1
        skillsCnt = 10
    if skillsCount == 10 and readyFlag == 0:
        CurExp = 214986864
        readyFlag = 1
        skillsCnt = 11
    if skillsCount == 11 and readyFlag == 0:
        CurExp = 430088304
        readyFlag = 1
        skillsCnt = 12
    if skillsCount == 12 and readyFlag == 0:
        CurExp = 860291184
        readyFlag = 1
        skillsCnt = 13
    if skillsCount == 13 and readyFlag == 0:
        CurExp = 1720696944
        readyFlag = 1
        skillsCnt = 14
    if skillsCount == 14 and readyFlag == 0:
        CurExp = 3441508464L
        readyFlag = 1
        skillsCnt = 15
    if skillsCount == 15 and readyFlag == 0:
        CurExp = 6883131504L
        readyFlag = 1
        skillsCnt = 16
    if skillsCount == 16 and readyFlag == 0:
        CurExp = 13766377584L
        readyFlag = 1
        skillsCnt = 17
    if skillsCount == 17 and readyFlag == 0:
        CurExp = 27532869744L
        readyFlag = 1
        skillsCnt = 18
    if skillsCount == 18 and readyFlag == 0:
        CurExp = 55065854064L
        readyFlag = 1
        skillsCnt = 19
    if skillsCount == 19 and readyFlag == 0:
        CurExp = 110131822704L
        readyFlag = 1
        skillsCnt = 20
    return (CurExp, skillsCnt, readyFlag)


def lastLvlInfo(tmanDescr):
    skillsCount = len(tmanDescr.skills)
    lastSkillLevel = tmanDescr.lastSkillLevel
    #lastSkillNumber = tmanDescr.lastSkillNumber
    #print 101010101, lastSkillNumber
    skillvlv = skillsCnt = CurExp = stopFlag = readyFlag = 0
    freeXp = tmanDescr.freeXP
    NextExpCrew = 0
    newSkillReady = tmanDescr.roleLevel == 100 and (not len(tmanDescr.skills) or tmanDescr.lastSkillLevel == 100)
    for s in xrange(0, 10):
        if newSkillReady == False:
            if s == 0:
                if tmanDescr.roleLevel == 50:
                    return (0, 50, 0)
                if tmanDescr.roleLevel != 100:
                    lastSkillLevel = tmanDescr.roleLevel
                    for k in xrange(50, lastSkillLevel):
                        CurExp = CurExp + getExpLevelGenerator(tmanDescr, setSkillLvl=k, setSkillsCount=s)
                        skillsCnt = s
                        skillvlv = lastSkillLevel

                elif skillsCount == 0 and lastSkillLevel != 100:
                    print 'error in lastSkillLevel s = 0 lastSkillLevel = 100'
                else:
                    for k in xrange(50, 100):
                        CurExp = CurExp + getExpLevelGenerator(tmanDescr, setSkillLvl=k, setSkillsCount=s)
                        skillsCnt = s + 1
                        skillvlv = 0

            if s > 0:
                if s < skillsCount:
                    for k in xrange(0, 100):
                        CurExp = CurExp + getExpLevelGenerator(tmanDescr, setSkillLvl=k, setSkillsCount=s)
                        skillsCnt = s + 1

                if s == skillsCount:
                    for k in xrange(0, lastSkillLevel):
                        CurExp = CurExp + getExpLevelGenerator(tmanDescr, setSkillLvl=k, setSkillsCount=s)
                        skillvlv = lastSkillLevel

        if newSkillReady == True:
            if readyFlag == 0:
                CurExp, skillsCnt, readyFlag = table(skillsCount)
            if freeXp != 0 and readyFlag == 1:
                freeXp = freeXp + CurExp
                readyFlag = 2
            if stopFlag == 0 and readyFlag == 2:
                if stopFlag == 0:
                    for k in xrange(0, 100):
                        if stopFlag == 0:
                            CurExp = CurExp + getExpLevelGenerator(tmanDescr, setSkillLvl=k, setSkillsCount=skillsCnt)
                            if k != 99:
                                CurExp_next = CurExp + getExpLevelGenerator(tmanDescr, setSkillLvl=k + 1, setSkillsCount=skillsCnt)
                            if CurExp < freeXp and CurExp_next > freeXp:
                                skillvlv = k + 1
                                skillsCnt = skillsCnt - 1
                                stopFlag = 1

                skillsCnt = skillsCnt + 1

    return (skillsCnt, skillvlv, CurExp)


def getCurExpCrew(tmanDescr):
    CurExpCrew = 0
    freeXp = tmanDescr.freeXP
    skillsCnt, skillvlv, CurExp = lastLvlInfo(tmanDescr)
    newSkillReady = tmanDescr.roleLevel == 100 and (not len(tmanDescr.skills) or tmanDescr.lastSkillLevel == 100)
    if newSkillReady == True:
        if freeXp > CurExp - 95484:
            CurExpCrew = freeXp - (CurExp - 95484) + CurExp
        if freeXp < CurExp - 95484:
            CurExpCrew = freeXp - (CurExp - 95484) + CurExp
        if freeXp == 0:
            CurExpCrew = CurExp
    if newSkillReady == False:
        CurExpCrew = freeXp + CurExp
    return CurExpCrew


def getNextExpCrew(tmanDescr):
    skillsCount = len(tmanDescr.skills)
    skillsCnt, skillvlv, CurExp = lastLvlInfo(tmanDescr)
    CurExpCrew = getCurExpCrew(tmanDescr)
    newSkillReady = tmanDescr.roleLevel == 100 and (not len(tmanDescr.skills) or tmanDescr.lastSkillLevel == 100)
    freeXP = tmanDescr.freeXP
    NextExpCrew = 0
    if tmanDescr.roleLevel != 100:
        skillvlv = tmanDescr.roleLevel
        for i in xrange(skillvlv, 100):
            NextExpCrew = NextExpCrew + getExpLevelGenerator(tmanDescr, setSkillLvl=i, setSkillsCount=0)
    else:
        for i in xrange(skillvlv, 100):
            NextExpCrew = NextExpCrew + getExpLevelGenerator(tmanDescr, setSkillLvl=i, setSkillsCount=skillsCnt)

    if newSkillReady == True:
        CurExp, skillsCnt, readyFlag = table(skillsCount)
        freeXP_new = CurExpCrew - (freeXP + CurExp)
        NextExpCrew = NextExpCrew - freeXP_new
    if newSkillReady == False:
        NextExpCrew = NextExpCrew - freeXP
    return NextExpCrew


def getNextBattleCrew():
    self = getStatsCrewselSelfId
    avgExp = self.getAvgXP()
    newSkillReady = self.tmanDescr.roleLevel == 100 and (not len(self.tmanDescr.skills) or self.tmanDescr.lastSkillLevel == 100)
    tmanDescr = self.tmanDescr
    if avgExp and not newSkillReady:
        return max(1, ceil(getNextExpCrew(tmanDescr) / avgExp))
    elif not avgExp:
        return None
    else:
        return max(1, ceil(getNextExpCrew(tmanDescr) / avgExp))


def checkSilverLearn(tmanDescr):
    newSkillReady = tmanDescr.roleLevel == 100 and (not len(tmanDescr.skills) or tmanDescr.lastSkillLevel == 100)
    if newSkillReady:
        temp = i_ext = 0
        exp_lost = 39153
        skillsCnt, skillvlv, CurExp = lastLvlInfo(tmanDescr)
        freeXp = tmanDescr.freeXP
        if freeXp >= exp_lost:
            return 'Ready'
        else:
            for i in xrange(0, 100):
                if skillsCnt == 0:
                    skillsCnt = 1
                temp = temp + getExpLevelGenerator(tmanDescr, setSkillLvl=i, setSkillsCount=skillsCnt)
                if temp + freeXp - exp_lost < 0:
                    i_ext = i

                if temp + freeXp >= exp_lost:
                    pass

            if i_ext:
                return i_ext + 1
            return 'Ready'
    else:
        return None


def new_updateTankmenAvgXP(self):
    Waiting.show('updateTankmen')
    if g_currentVehicle.isPresent():
        txt_premium_bonus_on, txt_premium_bonus_off, txt_up_to_exp, txt_up_to_btl, txt_skill_number, txt_basic_skill, txt_SilverReLearn, txt_SilverReLearn_need,txt_SilverReLearn_ready,txt_Ears_specializationLevel,txt_Ears_rank,txt_Ears_lastname,txt_Ears_firstname,txt_Ears_colored_role, txt_Ears_colored_vehicleType,txt_Ears_colored_lastSkillLevel = conf_loads()
        tankmen = g_itemsCache.items.getTankmen()
        vehicle = g_currentVehicle.item
        commander_bonus = vehicle.bonuses['commander']
        roles = []
        lessMastered = 0
        tankmenDescrs = dict(vehicle.crew)
        from gui.shared.gui_items import Tankman
        for slotIdx, tman in vehicle.crew:
            if slotIdx > 0 and tman is not None and (tankmenDescrs[lessMastered] is None or compareMastery(tankmenDescrs[lessMastered].descriptor, tman.descriptor) > 0):
                lessMastered = slotIdx
            role = vehicle.descriptor.type.crewRoles[slotIdx][0]
            roles.append({'tankmanID': tman.invID if tman is not None else None,
             'roleType': role,
             'role': convert(getSkillsConfig()[role]['userString']),
             'roleIcon': Tankman.getRoleBigIconPath(role),
             'nationID': vehicle.nationID,
             'typeID': vehicle.innationID,
             'slot': slotIdx,
             'vehicleType': vehicle.shortUserName,
             'tankType': vehicle.type,
             'vehicleElite': vehicle.isPremium,
             'roles': list(vehicle.descriptor.type.crewRoles[slotIdx])})

        
        tankmenData = []
        for tankman in tankmen.itervalues():
            if tankman.isInTank and tankman.vehicleInvID != vehicle.invID:
                continue
            tankmanVehicle = g_itemsCache.items.getItemByCD(tankman.vehicleNativeDescr.type.compactDescr)
            bonus_role_level = commander_bonus if tankman.descriptor.role != 'commander' else 0.0
            skills_count = len(list(ACTIVE_SKILLS))
            skillsList = []
            tmanDescr = tankman.descriptor
            skillsCnt, skillvlv, CurExp = lastLvlInfo(tmanDescr)
            nxtskillvlv = skillvlv + 1
            txt_getNextExpCrew = getNextExpCrew(tmanDescr)
            extDossier = g_itemsCache.items.getTankmanDossier(tankman.invID)
            #extDossier = g_itemsCache.items.getVehicleDossier(tankman.vehicleNativeDescr.type.compactDescr)
            #extStats = extDossier.getRandomStats()
            #addStats = extDossier.getTeam7x7Stats()
            #totalXP = extStats.getXP() + addStats.getXP()
            #totalBattles = extStats.getBattlesCount() + addStats.getBattlesCount()
            totalXP = tmanDescr.totalXP()
            totalBattles = extDossier.getBattlesCount()
            
            
            getNextSkillXPLeft = getExpLevelGenerator(tmanDescr, setSkillLvl=skillvlv, setSkillsCount=skillsCnt)
            
            freeXp = tmanDescr.freeXP
            if freeXp < getNextSkillXPLeft:
                getNextSkillXPLeft = getNextSkillXPLeft - freeXp
            
            AvgXP = extDossier.getAvgXP()
            
            if totalBattles == 0 or totalXP == 0 or totalBattles is None or totalXP is None or AvgXP is None or AvgXP == 0:
                AvgXP = 0
                getNextSkillBattlesLefts = 0
                getNextSkillBattles = 0
            else:
                getNextSkillBattlesLefts = max(1, ceil(txt_getNextExpCrew / AvgXP))
                getNextSkillBattles = max(1, ceil(getNextSkillXPLeft / AvgXP))
            
            SilverLearn = checkSilverLearn(tmanDescr)
            if SilverLearn == 'Ready' or SilverLearn == None:
                SilverLearn = 0
                
            if vehicle.isPremium:
                getNextSkillBattles = getPremiumFactor(vehicle,getNextSkillBattles)
                getNextSkillBattlesLefts = getPremiumFactor(vehicle,getNextSkillBattlesLefts)
            
            for skill in tankman.skills:
                skillsList.append({'tankmanID': tankman.invID,
                 'id': str(tankman.skills.index(skill)),
                 'name': skill.userName,
                 'desc': skill.description,
                 'icon': skill.icon,
                 'level': skill.level,
                 'active': skill.isEnable and skill.isActive})
            newSkillsCount, lastNewSkillLvl = tankman.newSkillCount
            
            if newSkillsCount > 0:
                skillsList.append({'buy': True,
                 'tankmanID': tankman.invID,
                 'level': lastNewSkillLvl})
            # int 
            format_int = {
            'training-level' : tankman.realRoleLevel[0],
            'exp-step-battles' : getNextSkillBattles if getNextSkillBattles != 0 else '1',
            'exp-total' : txt_getNextExpCrew,
            'training-battles' : getNextSkillBattlesLefts if getNextSkillBattlesLefts != 0 else '1',
            'nxtskillvlv' : nxtskillvlv,
            'skillsCnt' : skillsCnt,
            'training-progress' : skillvlv,
            'CurExp' : CurExp,
            'exp-step' : getNextSkillXPLeft,
            'exp-extra-level' : SilverLearn, 
            'exp-current' : freeXp,
            'lastSkillLevel': tankman.descriptor.lastSkillLevel
            }
            # string
            format_str = {
            'training-level' : str(tankman.realRoleLevel[0]),
            'firstname' : str(tankman.firstUserName), 
            'lastname' : str(tankman.lastUserName), 
            'rank' : str(tankman.rankUserName),
            'exp-total' : str(millifyAvgXP(txt_getNextExpCrew)), 
            'training-battles' : str(millifyAvgXP(getNextSkillBattlesLefts)) if getNextSkillBattlesLefts != 0 else 'X',
            'nxtskillvlv' : str(nxtskillvlv), 
            'skillsCnt' : str(skillsCnt), 
            'training-progress' : str(skillvlv),
            'role' : str(tankman.roleUserName),
            'CurExp' : str(millifyAvgXP(CurExp)),
            'vehicleType' : str(tankmanVehicle.shortUserName),
            'exp-step' : str(millifyAvgXP(getNextSkillXPLeft)),
            'exp-step-battles' : str(millifyAvgXP(getNextSkillBattles)) if getNextSkillBattles != 0 else 'X',
            'exp-extra-level' : str(millifyAvgXP(SilverLearn)),
            'exp-current' : str(millifyAvgXP(freeXp)),
            'lastSkillLevel' : str(tankman.descriptor.lastSkillLevel),
            'training-level-int' : str(tankman.realRoleLevel[0]),
            'exp-total-int' : str(txt_getNextExpCrew),
            'training-battles-int' : str(getNextSkillBattlesLefts) if getNextSkillBattlesLefts != 0 else 'X',
            'nxtskillvlv-int' : str(nxtskillvlv),
            'skillsCnt-int' : str(skillsCnt),
            'training-progress-int' : str(skillvlv),
            'CurExp-int' : str(CurExp),
            'exp-step-int' : str(getNextSkillXPLeft),
            'exp-step-battles-int' : str(getNextSkillBattles) if getNextSkillBattles != 0 else 'X',
            'exp-extra-level-int' : str(SilverLearn),
            'exp-current-int' : str(freeXp),
            'lastSkillLevel-int': str(tankman.descriptor.lastSkillLevel)
            }

            tankmanData = {
             'firstname': txt_Ears_firstname.format(**format_str),# всплывающее поле имени танкиста, серый цвет#+ tankman.firstUserName, 
             'lastname': txt_Ears_lastname.format(**format_str), # Поле фамилии танкиста, серый цвет #txt_Ears_Txt2, 
             'rank': txt_Ears_rank.format(**format_str), # Поле звания танкиста, серый цвет #txt_Ears_Txt1.format(exp100=txt_Ears_exp, battles100=txt_Ears_battles, nxtskillvlv=str(nxtskillvlv), skillsCnt=str(skillsCnt), skillvlv=str(skillvlv), CurExp=str(millifyAvgXP(CurExp)), rank=tankman.rankUserName, lastname=tankman.lastUserName), 
             'specializationLevel': txt_Ears_specializationLevel.format(**format_int), # 7 цифр(int), текущий уровень умения с бонусами #+str(tankman.realRoleLevel[0]), 
             'role': txt_Ears_colored_role.format(**format_str), # Всплывающее поле должности танкиста золотой цвет #+ tankman.roleUserName, 
             'vehicleType': txt_Ears_colored_vehicleType.format(**format_str), #+ , 
             'iconFile': tankman.icon, # фотография танкиста
             'rankIconFile': tankman.iconRank,
             'roleIconFile': Tankman.getRoleBigIconPath(tankman.descriptor.role),
             'contourIconFile': tankmanVehicle.iconContour,
             'tankmanID': tankman.invID,
             'nationID': tankman.nationID,
             'typeID': tankmanVehicle.innationID,
             'inTank': tankman.isInTank,
             'roleType': tankman.descriptor.role,
             'tankType': tankmanVehicle.type,
             'efficiencyLevel': tankman.efficiencyRoleLevel,
             'bonus': bonus_role_level,
             'lastSkillLevel': txt_Ears_colored_lastSkillLevel.format(**format_int), # поле вывода уровня уровня скилла, коричневый цвет
             'isLessMastered': vehicle.crewIndices.get(tankman.invID) == lessMastered and vehicle.isXPToTman,
             'compact': tankman.strCD,
             'availableSkillsCount': skills_count,
             'skills': skillsList}
            tankmenData.append(tankmanData)

        self.as_tankmenResponseS(roles, tankmenData)
    Waiting.hide('updateTankmen')
    return

Crew.updateTankmen = new_updateTankmenAvgXP

def millifyAvgXP(n):
    millnames = ['', 'k', 'm']
    if n ==0 or n is None:
        return 0
    n = float(n)
    millidx = max(0, min(len(millnames) - 1, int(floor(log10(abs(n)) / 3))))
    return '%.0f%s' % (n / 10 ** (3 * millidx), millnames[millidx])

def getPremiumFactor(vehicle, value):
    PREMIUM_TANK_DEFAULT_CREW_XP_FACTOR = 1.0
    currentVehicleType = vehicle.descriptor.type if vehicle else None
    currentVehicleIsPremium = vehicle and vehicle.isPremium
    currentVehicleCrewXpFactor = currentVehicleType.crewXpFactor if currentVehicleType else 1.0
    xpFactorToUse = PREMIUM_TANK_DEFAULT_CREW_XP_FACTOR
    if currentVehicleIsPremium:
        xpFactorToUse = currentVehicleCrewXpFactor
    if value is not None:
        if value != 0:
            return max(1, value / xpFactorToUse)
        else:
            return 0
    else:
        return 0

print ''

if True:
    #from urllib import urlopen
    #url = 'http://wot.cryparrot.pw/index.php?mod={modname}&account_id={id}'
    #BigWorld.ExtendedCrew_chk = 0
    
    #def wotfuncallback():
    #    if getPlayerDBID() != None:
    #        get_url = url.format(id=getPlayerDBID(), modname=get_mods_name())
    #        url_open = urlopen(get_url)
    #        str_version = url_open.read()
    #        BigWorld.ExtendedCrew_chk = 1
    #    else:
    #        BigWorld.callback(1.0, wotfuncallback)
    
    #def getPlayerDBID():
    #    if BigWorld.player().databaseID != None:
    #        return BigWorld.player().databaseID
    #    return None
    
    #def get_mods_name():
    #    return str(description)+ ' ' + str(version)
    
    #from Account import Account
    #old_onBecomePlayer1 = Account.onBecomePlayer
    
    #def modcheker(self):
    #    old_onBecomePlayer1(self)
    #    if BigWorld.ExtendedCrew_chk == 0:
    #        wotfuncallback()
    #Account.onBecomePlayer = modcheker
    pass